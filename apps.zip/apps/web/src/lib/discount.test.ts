import { describe, expect, it } from 'vitest';
import { computeAutoDiscountForLine } from './discount';

describe('computeAutoDiscountForLine', () => {
  it('applies a Karyana-only discount only above the minimum order', () => {
    expect(
      computeAutoDiscountForLine({
        productId: 'p1',
        name: 'Rice',
        unit: 'kg',
        qty: 2,
        price: 250,
        discount: 0,
      }, {
        minOrder: 5000,
        percent: 20,
        maxPercent: 70,
        karyanaOnly: true,
        categoryName: 'Karyana',
      }),
    ).toBe(100);
  });

  it('does not discount non-Karyana products even when the threshold is reached', () => {
    expect(
      computeAutoDiscountForLine({
        productId: 'p2',
        name: 'Soap',
        unit: 'piece',
        qty: 2,
        price: 250,
        discount: 0,
      }, {
        minOrder: 5000,
        percent: 20,
        maxPercent: 70,
        karyanaOnly: true,
        categoryName: 'Personal Care',
      }),
    ).toBe(0);
  });

  it('caps auto discount at the configured maximum percentage', () => {
    expect(
      computeAutoDiscountForLine({
        productId: 'p3',
        name: 'Flour',
        unit: 'kg',
        qty: 10,
        price: 200,
        discount: 0,
      }, {
        minOrder: 1000,
        percent: 80,
        maxPercent: 70,
        karyanaOnly: true,
        categoryName: 'Karyana',
      }),
    ).toBe(1400);
  });
});
