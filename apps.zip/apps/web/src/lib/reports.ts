import type { ReorderRow as DomainReorderRow } from '@retailos/domain';
import { apiRequest } from './api';
import { db, type Account, type Sale, type ServiceTxn } from './db';
import { holds } from './store';
import { rangeIso } from './format';

/**
 * Reports. The shop server adds everything up in the database (SUM / GROUP BY over the date range) and
 * sends back only the finished figures: the browser never downloads the bills, lines or ledger rows
 * behind a report, and cost / profit numbers are only produced for people allowed to see them.
 */

const q = (params: Record<string, string | number>) => new URLSearchParams(Object.entries(params).map(([k, v]) => [k, String(v)])).toString();
const get = <T>(path: string, params: Record<string, string | number> = {}) => apiRequest<T>(`/shop/reports/${path}?${q(params)}`);
const span = (from: string, to: string) => {
  const [start, end] = rangeIso(from, to);
  return { start, end };
};

export interface ProfitSummary {
  salesCount: number;
  grossSales: number;
  returns: number;
  revenue: number;
  cogs: number;
  grossProfit: number;
  expenses: number;
  stockLoss: number;
  serviceIncome: number;
  netProfit: number;
  drawings: number;
  expensesByCategory: Record<string, number>;
  byPayment: Record<string, number>;
  creditSales: number;
}

/**
 * Profit for a date range (local days, inclusive):
 *   revenue = sales − returns,  gross profit = revenue − cost of goods sold,
 *   net profit = gross profit + Easypaisa/JazzCash income − expenses − damaged/expired stock.
 * Owner withdrawals are shown separately and are NOT expenses.
 */
export const profitSummary = (from: string, to: string) => get<ProfitSummary>('profit', span(from, to));

export async function accountBalances(): Promise<Array<Account & { balance: number }>> {
  const accounts = await db.accounts.toArray();
  // Summed by the server; a person who may not see balances gets none.
  const totals = holds('accounts.view_balances', 'cash.session.view_expected', 'cash.session.review', 'retailer.transact')
    ? await apiRequest<Record<string, number>>('/shop/balances/accounts').catch(() => ({}) as Record<string, number>)
    : {};
  return accounts.filter((a) => a.active).map((a) => ({ ...a, balance: totals[a.id] ?? 0 }));
}

/** Balance per customer (they owe us) or supplier (we owe them). */
export async function partyBalances(partyType: 'customer' | 'supplier'): Promise<Map<string, number>> {
  if (!holds(partyType === 'customer' ? 'customers.view_balance' : 'suppliers.view_balance')) return new Map();
  const totals = await apiRequest<Record<string, number>>(`/shop/balances/parties?type=${partyType}`).catch(() => ({}) as Record<string, number>);
  return new Map(Object.entries(totals));
}

export type ReorderRow = DomainReorderRow;
export type ReorderStatus = ReorderRow['status'];

export interface ReorderResult {
  rows: ReorderRow[];
  summary: { activeProducts: number; stockValue: number | null; orderNow: number; reorderSoon: number; outOfStock: number };
}

/**
 * Which products to reorder, with the stock cards. The server works it out; this only tells it what day it is
 * here (so "today" is the shop's day, not the server's). `rows: false` returns just the card figures.
 */
export const reorderReport = (defaultLeadDays: number, opts: { coverDays?: number; rows?: boolean } = {}) =>
  get<ReorderResult>('reorder', { now: Date.now(), tz: new Date().getTimezoneOffset(), lead: defaultLeadDays, cover: opts.coverDays ?? 7, rows: opts.rows === false ? 0 : 1 });

export interface ProductSalesRow {
  productId: string;
  name: string;
  qty: number;
  revenue: number;
  cost: number;
  profit: number;
}

/** Units sold and profit per product in a range (top sellers). */
export const productSales = (from: string, to: string) => get<ProductSalesRow[]>('products', span(from, to));

export interface ServiceSummary {
  count: number;
  cashIn: number;
  cashOut: number;
  volume: number;
  commission: number;
  fees: number;
  txns: ServiceTxn[];
}

/** Retailer (Easypaisa/JazzCash) summary for a range. Totals come from the server; the list of that day's transactions is only fetched when asked for. */
export async function serviceSummary(provider: string, from: string, to: string, withTxns = false): Promise<ServiceSummary> {
  const totals = await get<Omit<ServiceSummary, 'txns'>>('services', { provider, ...span(from, to) });
  if (!withTxns) return { ...totals, txns: [] };
  const [start, end] = rangeIso(from, to);
  const txns = await db.serviceTxns.where('date').between(start, end, true, true).filter((t) => t.provider === provider).toArray();
  return { ...totals, txns };
}

export const salesSummary = (from: string, to: string) => get<{ bills: number; total: number; returns: number; cancelled: number }>('sales-summary', span(from, to));
export const topProducts = (from: string, to: string, limit = 5) => get<{ productId: string; name: string; qty: number; revenue: number }[]>('top-products', { ...span(from, to), limit });
export const dailySales = (days: string[]) => get<{ count: number; total: number }[]>('daily-sales', { ranges: JSON.stringify(days.map((d) => rangeIso(d, d))) });
export const salesVelocity = (sinceIso: string) => get<Record<string, number>>('sales-velocity', { since: sinceIso });
export const expenseTotals = (from: string, to: string) => get<{ expenseTotal: number; drawingTotal: number; byCategory: [string, number][] }>('expenses', span(from, to));
export const purchaseTotals = (from: string, to: string) => get<{ count: number; total: number; paid: number }>('purchases', span(from, to));
export const cashBreakdown = (accountId: string, from: string, to: string) => get<[string, number][]>('cash-breakdown', { accountId, ...span(from, to) });
export const khataTotals = () => get<{ customerDue?: number; customersWithDue?: number; overLimit?: number; supplierDue?: number; supplierAccounts?: number }>('khata');

/** The newest completed bills (the server orders and limits them, applying who may see which bill). */
export const latestSales = (limit: number) => apiRequest<{ items: Sale[] }>(`/shop/c/sales?${q({ k3: 'completed', order: 'desc', limit })}`).then((r) => r.items);

/** Bills of a date range, newest first. `limit` pages the list; leave it out for every bill of the range. */
export const salesInRange = (from: string, to: string, limit?: number) => {
  const [start, end] = rangeIso(from, to);
  return apiRequest<{ items: Sale[] }>(`/shop/c/sales?${q({ from: start, to: end, order: 'desc', ...(limit ? { limit } : {}) })}`).then((r) => r.items);
};
