import type { ReactNode } from 'react';
import { Navigate, Route, Routes } from 'react-router';
import { Layout } from './components/Layout';
import { useSession, type Area } from './lib/session';
import { CashPage } from './pages/Cash';
import { CustomersPage } from './pages/Customers';
import { Dashboard } from './pages/Dashboard';
import { ExpensesPage } from './pages/Expenses';
import { InventoryPage } from './pages/Inventory';
import { Login } from './pages/Login';
import { PosPage } from './pages/Pos';
import { ProductsPage } from './pages/Products';
import { ReportsPage } from './pages/Reports';
import { SalesPage } from './pages/Sales';
import { ServicesPage } from './pages/Services';
import { SettingsPage } from './pages/Settings';
import { Setup } from './pages/Setup';
import { SuppliersPage } from './pages/Suppliers';

function Guard({ area, children }: { area: Area; children: ReactNode }) {
  const { can } = useSession();
  return can(area) ? <>{children}</> : <Navigate to={can('pos') ? '/pos' : '/'} replace />;
}

export function App() {
  const { ready, user, can, setupDone, has, logout } = useSession();
  if (!ready) return null;
  if (!user) return <Login />;
  if (setupDone === undefined) return null;
  if (!setupDone) {
    return has('settings.manage') ? (
      <Setup />
    ) : (
      <div className="grid min-h-full place-items-center p-6 text-center">
        <div>
          <h1 className="text-xl font-bold">The shop is not set up yet</h1>
          <p className="mt-2 text-slate-600">Ask the owner to sign in and finish the first-time setup.</p>
          <button className="mt-4 rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium hover:bg-slate-50" onClick={logout}>
            Sign out
          </button>
        </div>
      </div>
    );
  }

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={can('dashboard') ? <Dashboard /> : <Navigate to="/pos" replace />} />
        <Route path="pos" element={<Guard area="pos"><PosPage /></Guard>} />
        <Route path="sales" element={<Guard area="sales"><SalesPage /></Guard>} />
        <Route path="products" element={<Guard area="products"><ProductsPage /></Guard>} />
        <Route path="inventory" element={<Guard area="inventory"><InventoryPage /></Guard>} />
        <Route path="customers" element={<Guard area="customers"><CustomersPage /></Guard>} />
        <Route path="ghar-se-ghar-tak" element={<Navigate to="/pos" replace />} />
        <Route path="suppliers" element={<Guard area="suppliers"><SuppliersPage /></Guard>} />
        <Route path="expenses" element={<Guard area="expenses"><ExpensesPage /></Guard>} />
        <Route path="services" element={<Guard area="services"><ServicesPage /></Guard>} />
        <Route path="cash" element={<Guard area="closing"><CashPage /></Guard>} />
        <Route path="reports" element={<Guard area="reports"><ReportsPage /></Guard>} />
        <Route path="settings" element={<Guard area="settings"><SettingsPage /></Guard>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}
