import { useLiveQuery } from '../lib/store';
import { AlertTriangle, ArrowDownRight, ArrowRight, ArrowUpRight, CheckCircle2, Clock3, PackagePlus, ShoppingCart, TrendingDown, TrendingUp, Wallet } from 'lucide-react';
import { Link } from 'react-router';
import { cx } from '../components/ui';
import { db } from '../lib/db';
import { dayKey, daysAgo, fmtDateTime, rs } from '../lib/format';
import { accountBalances, dailySales, khataTotals, latestSales, profitSummary, reorderReport, topProducts as topProductsOf } from '../lib/reports';
import { useSession } from '../lib/session';

export function Dashboard() {
  const { settings } = useSession();
  const today = dayKey();
  const weekStart = daysAgo(6);
  const prevStart = daysAgo(13);
  const prevEnd = daysAgo(7);
  const weekDays = Array.from({ length: 7 }, (_, index) => daysAgo(6 - index));
  const data = useLiveQuery(async () => {
    // Every figure below is added up by the server; only the finished numbers come back.
    const [todayP, weekP, prevWeekP, accounts, khata, stock, closings, customers, recent, topProducts, daily] = await Promise.all([
      profitSummary(today, today),
      profitSummary(weekStart, today),
      profitSummary(prevStart, prevEnd),
      accountBalances(),
      khataTotals().catch(() => ({}) as Awaited<ReturnType<typeof khataTotals>>),
      reorderReport(settings?.leadDays ?? 2, { rows: false }).catch(() => null),
      db.closings.where('date').aboveOrEqual(new Date(`${today}T00:00:00`).toISOString()).toArray(),
      db.customers.toArray(),
      latestSales(6).catch(() => []),
      topProductsOf(weekStart, today, 5).catch(() => []),
      dailySales(weekDays).catch(() => weekDays.map(() => ({ count: 0, total: 0 }))),
    ]);
    return {
      todayP, weekP, prevWeekP, accounts, khata, stock, closings,
      recent, customers: new Map(customers.map((customer) => [customer.id, customer.name])),
      topProducts, dailyTotals: daily.map((day) => day.total),
    };
  }, [today, weekStart, prevStart, prevEnd, settings?.leadDays]);

  if (!data) return null;
  const { todayP, weekP, prevWeekP, accounts, khata, stock, closings, recent, customers, topProducts, dailyTotals } = data;
  const customerDue = khata.customerDue ?? 0;
  const supplierDue = khata.supplierDue ?? 0;
  const overLimit = khata.overLimit ?? 0;
  const orderNow = stock?.summary.orderNow ?? 0;
  const soon = stock?.summary.reorderSoon ?? 0;
  const growth = prevWeekP.revenue > 0 ? ((weekP.revenue - prevWeekP.revenue) / prevWeekP.revenue) * 100 : null;
  const cashAccount = accounts.find((account) => account.type === 'cash');
  const dailySalesTotals = dailyTotals;
  const maxDaily = Math.max(1, ...dailySalesTotals);
  const averageBill = todayP.salesCount ? Math.round(todayP.revenue / todayP.salesCount) : 0;
  const activeProducts = stock?.summary.activeProducts ?? 0;
  const alerts: { tone: 'red' | 'amber' | 'green'; text: string; to: string }[] = [];
  if (orderNow) alerts.push({ tone: 'red', text: `${orderNow} product${orderNow === 1 ? '' : 's'} need ordering now.`, to: '/inventory' });
  if (soon) alerts.push({ tone: 'amber', text: `${soon} product${soon === 1 ? '' : 's'} approaching reorder point.`, to: '/inventory' });
  if (overLimit) alerts.push({ tone: 'amber', text: `${overLimit} customer${overLimit === 1 ? '' : 's'} over credit limit.`, to: '/customers' });
  if (supplierDue > 0) alerts.push({ tone: 'amber', text: `Supplier balances due: ${rs(supplierDue)}.`, to: '/suppliers' });
  const bigDifference = closings.find((closing) => Math.abs(closing.difference) >= (settings?.discrepancyLimit ?? 50000));
  if (bigDifference) alerts.push({ tone: 'red', text: `Today's cash difference is ${rs(bigDifference.difference)}.`, to: '/cash' });
  if (closings.length === 0 && new Date().getHours() >= 20) alerts.push({ tone: 'amber', text: 'Daily cash closing is still open.', to: '/cash' });

  return (
    <div className="space-y-5 pb-8">
      <header className="relative isolate overflow-hidden rounded-lg bg-slate-950 px-5 py-6 text-white sm:px-7 sm:py-8">
        <div className="absolute inset-y-0 right-0 -z-10 w-2/3 bg-[linear-gradient(115deg,transparent_15%,rgba(13,148,136,0.32)_15%,rgba(13,148,136,0.12)_62%,transparent_62%)]" />
        <div className="flex flex-wrap items-end justify-between gap-5">
          <div>
            <div className="mb-3 flex items-center gap-2 text-xs font-semibold uppercase text-teal-300">Trading desk <span className="h-px w-8 bg-teal-400" /> {today}</div>
            <h1 className="text-2xl font-bold sm:text-3xl">{settings?.shopName ?? 'Shop dashboard'}</h1>
            <p className="mt-1 text-sm text-slate-300">A clear view of today’s trade, cash and stock.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Link to="/suppliers" className="inline-flex items-center gap-2 rounded-md border border-white/25 px-3 py-2 text-sm font-medium text-white hover:bg-white/10"><PackagePlus size={16} /> Receive stock</Link>
            <Link to="/pos" className="inline-flex items-center gap-2 rounded-md bg-teal-500 px-3 py-2 text-sm font-semibold text-slate-950 hover:bg-teal-400"><ShoppingCart size={16} /> New sale</Link>
          </div>
        </div>
        <div className="mt-7 grid gap-5 border-t border-white/15 pt-5 sm:grid-cols-3">
          <div><div className="text-xs text-slate-400">Sales today</div><div className="mt-1 text-2xl font-bold tabular-nums">{rs(todayP.revenue)}</div><div className="mt-1 text-xs text-slate-400">{todayP.salesCount} bills · average {rs(averageBill)}</div></div>
          <div><div className="text-xs text-slate-400">Gross profit</div><div className={cx('mt-1 text-2xl font-bold tabular-nums', todayP.grossProfit >= 0 ? 'text-emerald-300' : 'text-rose-300')}>{rs(todayP.grossProfit)}</div><div className="mt-1 text-xs text-slate-400">Sales less product cost {rs(todayP.cogs)}</div></div>
          <div><div className="text-xs text-slate-400">Cash expected</div><div className="mt-1 text-2xl font-bold tabular-nums">{rs(cashAccount?.balance ?? 0)}</div><div className="mt-1 text-xs text-slate-400">Net profit {rs(todayP.netProfit)}</div></div>
        </div>
      </header>

      <section aria-label="Business balances" className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <div className="rounded-md border-l-4 border-amber-400 bg-white px-4 py-3 shadow-sm"><div className="text-xs font-medium text-slate-500">Customer credit</div><div className="mt-1 text-xl font-bold tabular-nums">{rs(customerDue)}</div><div className="mt-1 text-xs text-slate-500">Outstanding udhaar</div></div>
        <div className="rounded-md border-l-4 border-rose-400 bg-white px-4 py-3 shadow-sm"><div className="text-xs font-medium text-slate-500">Supplier due</div><div className="mt-1 text-xl font-bold tabular-nums">{rs(supplierDue)}</div><div className="mt-1 text-xs text-slate-500">{khata.supplierAccounts ?? 0} supplier accounts</div></div>
        <div className="rounded-md border-l-4 border-sky-400 bg-white px-4 py-3 shadow-sm"><div className="text-xs font-medium text-slate-500">Inventory at cost</div><div className="mt-1 text-xl font-bold tabular-nums">{rs(stock?.summary.stockValue ?? 0)}</div><div className="mt-1 text-xs text-slate-500">{activeProducts} active products</div></div>
        <div className="rounded-md border-l-4 border-teal-500 bg-white px-4 py-3 shadow-sm"><div className="text-xs font-medium text-slate-500">Weekly sales</div><div className="mt-1 text-xl font-bold tabular-nums">{rs(weekP.revenue)}</div><div className={cx('mt-1 inline-flex items-center gap-1 text-xs', growth === null ? 'text-slate-500' : growth >= 0 ? 'text-emerald-700' : 'text-rose-700')}>{growth === null ? 'No comparison yet' : <>{growth >= 0 ? <ArrowUpRight size={13} /> : <ArrowDownRight size={13} />}{growth > 0 ? '+' : ''}{growth.toFixed(1)}% vs previous week</>}</div></div>
      </section>

      <section className="grid gap-4 xl:grid-cols-[minmax(0,1.35fr)_minmax(300px,0.65fr)]">
        <div className="rounded-lg border border-slate-200 bg-white">
          <div className="flex items-start justify-between gap-3 border-b border-slate-100 px-4 py-3 sm:px-5"><div><h2 className="font-semibold text-slate-900">Sales movement</h2><p className="mt-0.5 text-xs text-slate-500">Daily totals · last 7 days</p></div><Link to="/reports" className="text-sm font-medium text-brand-700 hover:underline">Reports <ArrowRight size={13} className="ml-1 inline" /></Link></div>
          <div className="grid grid-cols-7 gap-2 px-4 pb-4 pt-5 sm:gap-4 sm:px-5" aria-label="Daily sales for the last seven days">
            {dailySalesTotals.map((amount, index) => <div key={weekDays[index]} className="flex min-w-0 flex-col items-center gap-2">
              <span className="w-full truncate text-center text-[10px] tabular-nums text-slate-500">{amount ? rs(amount) : '—'}</span>
              <div className="flex h-32 w-full items-end border-b border-slate-200 bg-slate-50"><div className={cx('w-full transition-[height]', weekDays[index] === today ? 'bg-amber-400' : 'bg-teal-600')} style={{ height: `${Math.max(amount ? 7 : 2, amount / maxDaily * 100)}%` }} title={`${weekDays[index]}: ${rs(amount)}`} /></div>
              <span className={cx('text-xs', weekDays[index] === today ? 'font-semibold text-slate-900' : 'text-slate-500')}>{new Date(`${weekDays[index]}T12:00:00`).toLocaleDateString('en-PK', { weekday: 'short' })}</span>
            </div>)}
          </div>
          <div className="flex flex-wrap justify-between gap-2 border-t border-slate-100 px-4 py-3 text-sm sm:px-5"><span className="text-slate-500">Bills this week <b className="ml-1 text-slate-900">{weekP.salesCount}</b></span><span className="text-slate-500">Net profit <b className="ml-1 text-slate-900">{rs(weekP.netProfit)}</b></span></div>
        </div>

        <div className="rounded-lg border border-slate-200 bg-white">
          <div className="flex items-center justify-between gap-2 border-b border-slate-100 px-4 py-3"><div><h2 className="font-semibold text-slate-900">Action queue</h2><p className="text-xs text-slate-500">{alerts.length ? `${alerts.length} items need a look` : 'You are clear for now'}</p></div><span className={cx('grid h-7 min-w-7 place-items-center rounded px-2 text-xs font-semibold', alerts.length ? 'bg-amber-100 text-amber-900' : 'bg-emerald-100 text-emerald-800')}>{alerts.length || <CheckCircle2 size={15} />}</span></div>
          {alerts.length === 0 ? <div className="flex items-center gap-2 px-4 py-5 text-sm text-emerald-800"><CheckCircle2 size={17} /> Nothing urgent right now.</div> : <ul className="divide-y divide-slate-100">
            {alerts.map((alert, index) => <li key={index}><Link to={alert.to} className="flex items-start gap-3 px-4 py-3 text-sm hover:bg-slate-50"><span className={cx('mt-1 h-2 w-2 shrink-0 rounded-full', alert.tone === 'red' ? 'bg-rose-500' : alert.tone === 'amber' ? 'bg-amber-500' : 'bg-emerald-500')} /><span className="min-w-0 flex-1">{alert.text}</span><ArrowRight size={14} className="mt-0.5 shrink-0 text-slate-400" /></Link></li>)}
          </ul>}
          <div className="grid grid-cols-2 border-t border-slate-100 text-center"><Link to="/inventory" className="border-r border-slate-100 px-3 py-3 hover:bg-slate-50"><span className="block text-lg font-bold text-rose-700">{orderNow}</span><span className="text-xs text-slate-500">Order now</span></Link><Link to="/inventory" className="px-3 py-3 hover:bg-slate-50"><span className="block text-lg font-bold text-amber-700">{soon}</span><span className="text-xs text-slate-500">Reorder soon</span></Link></div>
        </div>
      </section>

      <section className="grid gap-4 xl:grid-cols-2">
        <div className="rounded-lg border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3"><div><h2 className="font-semibold text-slate-900">Latest transactions</h2><p className="text-xs text-slate-500">Most recent completed bills</p></div><Link to="/sales" className="text-sm font-medium text-brand-700 hover:underline">All sales <ArrowRight size={13} className="ml-1 inline" /></Link></div>
          {recent.length === 0 ? <p className="px-4 py-5 text-sm text-slate-500">No completed sales recorded yet.</p> : <ul className="divide-y divide-slate-100">
            {recent.map((sale) => <li key={sale.id}><Link to="/sales" className="flex items-center gap-3 px-4 py-3 hover:bg-slate-50"><Clock3 size={15} className="shrink-0 text-slate-400" /><span className="min-w-0 flex-1"><span className="block truncate text-sm font-semibold text-slate-900">{sale.no} · {sale.customerId ? customers.get(sale.customerId) ?? 'Customer' : 'Walk-in'}</span><span className="text-xs text-slate-500">{fmtDateTime(sale.date)} · {sale.items.length} items{sale.credit ? ' · Udhaar' : ''}</span></span><span className="shrink-0 text-sm font-semibold tabular-nums">{rs(sale.total)}</span></Link></li>)}
          </ul>}
        </div>
        <div className="rounded-lg border border-slate-200 bg-white">
          <div className="flex items-center justify-between border-b border-slate-100 px-4 py-3"><div><h2 className="font-semibold text-slate-900">Best sellers</h2><p className="text-xs text-slate-500">Ranked by quantity · this week</p></div><Link to="/reports" className="text-sm font-medium text-brand-700 hover:underline">Product report <ArrowRight size={13} className="ml-1 inline" /></Link></div>
          {topProducts.length === 0 ? <p className="px-4 py-5 text-sm text-slate-500">Rankings appear when sales are recorded.</p> : <ul className="divide-y divide-slate-100">
            {topProducts.map((product, index) => <li key={`${product.name}-${index}`} className="flex items-center gap-3 px-4 py-3"><span className={cx('grid h-7 w-7 place-items-center rounded text-xs font-bold', index === 0 ? 'bg-amber-100 text-amber-900' : 'bg-slate-100 text-slate-600')}>{String(index + 1).padStart(2, '0')}</span><span className="min-w-0 flex-1 truncate text-sm font-semibold text-slate-900">{product.name}</span><span className="text-xs tabular-nums text-slate-500">{product.qty} sold</span><span className="text-sm font-semibold tabular-nums">{rs(product.revenue)}</span></li>)}
          </ul>}
        </div>
      </section>
    </div>
  );
}
