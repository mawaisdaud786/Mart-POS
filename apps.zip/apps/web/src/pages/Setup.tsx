import { Store } from 'lucide-react';
import { useState } from 'react';
import { Button, Field, Input, MoneyInput, useAction } from '../components/ui';
import { setupShop } from '../lib/ops';
import { useSession } from '../lib/session';

/** First run, done once by the owner after signing in: shop details, default payment accounts and opening cash. */
export function Setup() {
  const { logout, user } = useSession();
  const [shopName, setShopName] = useState('');
  const [address, setAddress] = useState('');
  const [phone, setPhone] = useState('');
  const [openingCash, setOpeningCash] = useState(0);
  const run = useAction();

  return (
    <div className="flex min-h-full items-center justify-center p-4">
      <div className="w-full max-w-lg rounded-2xl bg-white p-6 shadow-lg">
        <div className="mb-5 flex items-center gap-3">
          <div className="grid h-11 w-11 place-items-center rounded-xl bg-brand-600 text-white">
            <Store />
          </div>
          <div>
            <h1 className="text-xl font-bold">Welcome{user ? `, ${user.name}` : ''}</h1>
            <p className="text-sm text-slate-500">Set up your shop. Takes one minute.</p>
          </div>
        </div>
        <div className="grid gap-4">
          <Field label="Shop name">
            <Input value={shopName} onChange={(e) => setShopName(e.target.value)} autoFocus />
          </Field>
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Phone">
              <Input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="03xx-xxxxxxx" />
            </Field>
            <Field label="Opening cash in drawer (Rs)">
              <MoneyInput value={openingCash} onChange={setOpeningCash} />
            </Field>
          </div>
          <Field label="Address">
            <Input value={address} onChange={(e) => setAddress(e.target.value)} />
          </Field>
          <p className="text-sm text-slate-500">Your payment accounts (cash, bank, Easypaisa, JazzCash) and product categories are created for you; change them later in Settings.</p>
          <div className="flex gap-2">
            <Button size="lg" className="flex-1" disabled={!shopName.trim()} onClick={() => run(() => setupShop({ shopName: shopName.trim(), address, phone, openingCash }), 'Shop is ready')}>
              Start using RetailOS
            </Button>
            <Button size="lg" variant="ghost" onClick={logout}>
              Sign out
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
