import { useLiveQuery } from '../lib/store';
import { Boxes, Download, Mic, Package, Pencil, Plus, Search, Star, Tags, Trash2, Upload, X } from 'lucide-react';
import { useMemo, useState } from 'react';
import { Badge, Button, Card, Empty, Field, Input, Modal, MoneyInput, PageHeader, Select, cx, td, th, useAction, useToast } from '../components/ui';
import { db, nowIso, uid, UNITS, type Product, type StockMove } from '../lib/db';
import { qty, rs } from '../lib/format';
import { adjustStock, importProducts as importProductsOp, type ImportRecord } from '../lib/ops';
import { useSession } from '../lib/session';
import { useSpeech, type SpeechLang } from '../lib/voice/speech';
import { useVoiceLang } from '../lib/prefs';
import { csvCell } from '../lib/safe';

const PRODUCT_IMPORT_HEADERS = ['Sr', 'Product Name', 'Stock', 'Purchase Unit Price', 'Qty/ Unit', 'Purchase Unit', 'Purchase Price/ Piece', 'Sale Unit', 'Unit Sale Price', 'Sale Margin', 'Supplier', 'Product Category'];
const IMPORT_HEADER_ALIASES: Record<string, string[]> = {
  sku: ['sku', 'sr'],
  name: ['name', 'product name'],
  category: ['category', 'product category'],
  unit: ['unit', 'sale unit'],
  'pack name': ['pack name', 'purchase unit'],
  'pack size': ['pack size', 'qty unit', 'qty per unit'],
  'sale price (rs)': ['sale price (rs)', 'sale price', 'unit sale price'],
  'threshold price (rs)': ['threshold price (rs)', 'threshold price', 'special price'],
  'wholesale price (rs)': ['wholesale price (rs)', 'wholesale price', 'shopkeeper price'],
  'cost (rs)': ['cost (rs)', 'cost', 'purchase price piece', 'purchase price per piece'],
  'purchase unit price': ['purchase unit price'],
  'opening stock': ['opening stock', 'stock'],
  'minimum stock': ['minimum stock', 'min stock'],
  favorite: ['favorite', 'favourite'],
};

function normalizeHeader(header: string): string {
  const normalized = header.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
  for (const [canonical, aliases] of Object.entries(IMPORT_HEADER_ALIASES)) {
    if (aliases.some((alias) => alias.replace(/[^a-z0-9]+/g, ' ').trim() === normalized)) return canonical;
  }
  return normalized;
}

function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  const input = text.replace(/^\uFEFF/, '');
  for (let index = 0; index < input.length; index += 1) {
    const char = input[index];
    if (char === '"') {
      if (quoted && input[index + 1] === '"') {
        cell += '"';
        index += 1;
      } else quoted = !quoted;
    } else if (char === ',' && !quoted) {
      row.push(cell.trim());
      cell = '';
    } else if ((char === '\n' || char === '\r') && !quoted) {
      if (char === '\r' && input[index + 1] === '\n') index += 1;
      row.push(cell.trim());
      if (row.some(Boolean)) rows.push(row);
      row = [];
      cell = '';
    } else cell += char;
  }
  if (quoted) throw new Error('CSV contains an unclosed quoted field');
  row.push(cell.trim());
  if (row.some(Boolean)) rows.push(row);
  return rows;
}

function downloadProducts(products: Product[], categories: { id: string; name: string }[], suppliers: { id: string; name: string }[], showCost: boolean) {
  const costHeaders = new Set(['Purchase Unit Price', 'Purchase Price/ Piece', 'Sale Margin']);
  const headers = PRODUCT_IMPORT_HEADERS.filter((header) => showCost || !costHeaders.has(header));
  const rows = products.map((product) => {
    const costPerPiece = product.cost / 100;
    const values: Record<string, string | number | boolean | undefined> = {
      Sr: product.sku,
      'Product Name': product.name,
      Stock: product.stock,
      'Purchase Unit Price': costPerPiece * (product.packSize ?? 1),
      'Qty/ Unit': product.packSize,
      'Purchase Unit': product.packName,
      'Purchase Price/ Piece': costPerPiece,
      'Sale Unit': product.unit,
      'Unit Sale Price': product.salePrice / 100,
      'Sale Margin': product.salePrice > 0 && product.cost > 0 ? ((product.salePrice - product.cost) / product.salePrice) * 100 : '',
      Supplier: suppliers.find((supplier) => supplier.id === product.supplierId)?.name,
      'Product Category': categories.find((category) => category.id === product.categoryId)?.name,
    };
    return headers.map((header) => csvCell(values[header]));
  });
  const csv = [headers.map(csvCell), ...rows].map((row) => row.join(',')).join('\r\n');
  const url = URL.createObjectURL(new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' }));
  const link = Object.assign(document.createElement('a'), { href: url, download: `products-${new Date().toISOString().slice(0, 10)}.csv` });
  link.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function ProductsPage() {
  const { can } = useSession();
  const products = useLiveQuery(() => db.products.toArray(), []) ?? [];
  const categories = useLiveQuery(() => db.categories.orderBy('name').toArray(), []) ?? [];
  const suppliers = useLiveQuery(() => db.suppliers.orderBy('name').toArray(), []) ?? [];
  const [q, setQ] = useState('');
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [categoryMenuOpen, setCategoryMenuOpen] = useState(false);
  const [showInactive, setShowInactive] = useState(false);
  const [page, setPage] = useState(0);
  const [editing, setEditing] = useState<Product | 'new' | null>(null);
  const [adjusting, setAdjusting] = useState<Product | null>(null);
  const [managingCats, setManagingCats] = useState(false);
  const [importSummary, setImportSummary] = useState('');
  const run = useAction();
  const showCost = can('cost');

  const importProducts = (file: File) =>
    run(async () => {
      const rows = parseCsv(await file.text());
      if (rows.length < 2) throw new Error('CSV must include a header row and at least one product');
      const headers = rows[0].map(normalizeHeader);
      const column = (name: string) => headers.indexOf(name);
      for (const required of ['sku', 'name', 'sale price (rs)']) {
        if (column(required) < 0) throw new Error(`CSV is missing the "${required}" column`);
      }

      const records = rows.slice(1).map((row, index) => {
        const value = (name: string) => (column(name) < 0 ? '' : row[column(name)] ?? '').trim();
        const rowNumber = index + 2;
        const sku = value('sku');
        const name = value('name');
        const priceText = value('sale price (rs)');
        const salePrice = Number(priceText);
        if (!sku || !name) throw new Error(`Row ${rowNumber}: SKU and name are required`);
        if (!priceText || !Number.isFinite(salePrice) || salePrice <= 0) throw new Error(`Row ${rowNumber}: sale price must be greater than zero`);
        const thresholdText = value('threshold price (rs)');
        const thresholdPrice = thresholdText ? Number(thresholdText) : undefined;
        const wholesaleText = value('wholesale price (rs)');
        const wholesalePrice = wholesaleText ? Number(wholesaleText) : undefined;
        if (thresholdPrice !== undefined && (!Number.isFinite(thresholdPrice) || thresholdPrice < 0 || thresholdPrice > salePrice)) throw new Error(`Row ${rowNumber}: threshold price must be between zero and sale price`);
        if (wholesalePrice !== undefined && (!Number.isFinite(wholesalePrice) || wholesalePrice < 0)) throw new Error(`Row ${rowNumber}: wholesale price must be zero or greater`);
        const minStockText = value('minimum stock');
        const packSizeText = value('pack size');
        const minStock = minStockText ? Number(minStockText) : 0;
        const packSize = packSizeText ? Number(packSizeText) : undefined;
        if (!Number.isFinite(minStock) || minStock < 0) throw new Error(`Row ${rowNumber}: minimum stock must be zero or greater`);
        if (packSize !== undefined && (!Number.isFinite(packSize) || packSize <= 0)) throw new Error(`Row ${rowNumber}: pack size must be greater than zero`);
        const openingStockText = value('opening stock');
        const openingStock = openingStockText ? Number(openingStockText) : 0;
        if (!Number.isFinite(openingStock) || openingStock < 0) throw new Error(`Row ${rowNumber}: opening stock must be zero or greater`);
        const costText = value('cost (rs)');
        const purchaseUnitPriceText = value('purchase unit price');
        const purchaseUnitPrice = purchaseUnitPriceText ? Number(purchaseUnitPriceText) : undefined;
        const cost = costText
          ? Number(costText)
          : purchaseUnitPrice === undefined
            ? undefined
            : purchaseUnitPrice / (packSize ?? 1);
        if (cost !== undefined && (!Number.isFinite(cost) || cost < 0)) throw new Error(`Row ${rowNumber}: cost must be zero or greater`);
        const parseFlag = (text: string, fallback: boolean) => {
          if (!text) return fallback;
          if (['true', '1', 'yes'].includes(text.toLowerCase())) return true;
          if (['false', '0', 'no'].includes(text.toLowerCase())) return false;
          throw new Error(`Row ${rowNumber}: use true or false for favorite and active`);
        };
        return {
          rowNumber,
          sku,
          name,
          nameUr: value('urdu name') || undefined,
          voiceKeywords: column('voice keywords') >= 0
            ? value('voice keywords').split(/[;,|]/).map((keyword) => keyword.trim()).filter(Boolean)
            : undefined,
          barcode: value('barcode') || undefined,
          category: value('category'),
          supplier: value('supplier'),
          unit: value('unit') || 'Piece',
          packName: value('pack name') || undefined,
          packSize,
          salePrice: Math.round(salePrice * 100),
          thresholdPrice: thresholdPrice === undefined ? undefined : Math.round(thresholdPrice * 100),
          wholesalePrice: wholesalePrice === undefined ? undefined : Math.round(wholesalePrice * 100),
          cost: cost === undefined ? undefined : Math.round(cost * 100),
          openingStock,
          minStock,
          favorite: parseFlag(value('favorite'), false),
          active: parseFlag(value('active'), true),
        };
      });

      const seenSkus = new Set<string>();
      const seenBarcodes = new Set<string>();
      for (const record of records) {
        const normalizedSku = record.sku.toLowerCase();
        if (seenSkus.has(normalizedSku)) throw new Error(`Row ${record.rowNumber}: duplicate SKU ${record.sku} in CSV`);
        seenSkus.add(normalizedSku);
        if (record.barcode) {
          if (seenBarcodes.has(record.barcode)) throw new Error(`Row ${record.rowNumber}: duplicate barcode ${record.barcode} in CSV`);
          seenBarcodes.add(record.barcode);
        }
      }

      // The server matches products by SKU, creates missing categories and suppliers, checks barcodes and
      // records opening stock, all in one step. Cost and price changes need the matching permission there.
      const result = await importProductsOp(records.map(({ rowNumber: _row, ...record }) => record as ImportRecord));
      setImportSummary(`Imported ${result.added} new and updated ${result.updated} products${result.suppliersAdded ? `; added ${result.suppliersAdded} suppliers` : ''}.`);
    }, 'Product import complete');

  const list = useMemo(() => {
    const s = q.trim().toLowerCase();
    return products
      .filter((p) => (showInactive ? true : p.active))
      .filter((p) => selectedCategories.length === 0 || selectedCategories.includes(p.categoryId ?? ''))
      .filter((p) => !s || p.name.toLowerCase().includes(s) || p.sku.toLowerCase().includes(s) || p.barcode?.includes(s) || p.nameUr?.includes(q.trim()))
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [products, q, selectedCategories, showInactive]);

  const pageSize = 25;
  const pageCount = Math.ceil(list.length / pageSize);
  const visiblePage = Math.min(page, Math.max(0, pageCount - 1));
  const pageProducts = list.slice(visiblePage * pageSize, (visiblePage + 1) * pageSize);
  const firstVisible = list.length ? visiblePage * pageSize + 1 : 0;
  const lastVisible = Math.min((visiblePage + 1) * pageSize, list.length);

  const catName = (id?: string) => categories.find((c) => c.id === id)?.name ?? '—';

  return (
    <div>
      <PageHeader
        title="Products"
        subtitle={`${products.filter((p) => p.active).length} active products`}
        actions={
          <>
            <Button
              variant="secondary"
              onClick={() =>
                run(async () => {
                  const [allProducts, allCategories, allSuppliers] = await Promise.all([
                    db.products.toArray(),
                    db.categories.toArray(),
                    db.suppliers.toArray(),
                  ]);
                  downloadProducts(allProducts, allCategories, allSuppliers, showCost);
                }, 'Product CSV downloaded')
              }
            >
              <Download size={16} /> Export CSV
            </Button>
            <label className="inline-flex cursor-pointer items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50">
              <Upload size={16} /> Import CSV
              <input
                type="file"
                accept=".csv,text/csv"
                className="hidden"
                onChange={(event) => {
                  const file = event.target.files?.[0];
                  event.target.value = '';
                  if (file) importProducts(file);
                }}
              />
            </label>
            <Button variant="secondary" onClick={() => setManagingCats(true)}>
              <Tags size={16} /> Categories
            </Button>
            <Button onClick={() => setEditing('new')}>
              <Plus size={16} /> Add product
            </Button>
          </>
        }
      />
      {importSummary && <p className="mb-3 text-sm text-emerald-700">{importSummary}</p>}
      <Card>
        <div className="flex flex-wrap items-center gap-2 border-b border-slate-100 p-3">
          <div className="relative min-w-[220px] flex-1">
            <Search size={16} className="absolute top-1/2 left-3 -translate-y-1/2 text-slate-400" />
            <Input className="pl-9" placeholder="Search name, SKU, barcode…" value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }} />
          </div>
          <div className="relative">
            <Button variant="secondary" aria-expanded={categoryMenuOpen} onClick={() => setCategoryMenuOpen((open) => !open)}>
              <Tags size={16} /> {selectedCategories.length ? `Categories (${selectedCategories.length})` : 'All categories'}
            </Button>
            {categoryMenuOpen && (
              <div className="absolute right-0 z-20 mt-1 max-h-72 w-64 overflow-y-auto rounded-lg border border-slate-200 bg-white p-2 shadow-lg">
                <div className="mb-1 flex items-center justify-between border-b border-slate-100 px-2 py-1.5 text-xs font-semibold text-slate-500">
                  <span>Filter categories</span>
                  {selectedCategories.length > 0 && (
                    <button className="text-brand-700 hover:underline" onClick={() => { setSelectedCategories([]); setPage(0); }}>
                      Clear
                    </button>
                  )}
                </div>
                {categories.map((category) => (
                  <label key={category.id} className="flex cursor-pointer items-center gap-2 rounded px-2 py-1.5 text-sm hover:bg-slate-50">
                    <input
                      type="checkbox"
                      checked={selectedCategories.includes(category.id)}
                      onChange={(event) => {
                        setSelectedCategories((current) => event.target.checked
                          ? [...current, category.id]
                          : current.filter((id) => id !== category.id));
                        setPage(0);
                      }}
                    />
                    <span>{category.name}</span>
                  </label>
                ))}
              </div>
            )}
          </div>
          <label className="flex items-center gap-2 text-sm text-slate-600">
            <input type="checkbox" checked={showInactive} onChange={(e) => { setShowInactive(e.target.checked); setPage(0); }} /> Show inactive
          </label>
        </div>
        {list.length === 0 ? (
          <Empty icon={<Package size={40} />} title="No products yet">
            Click "Add product" to create your first product.
          </Empty>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className={th}>Product</th>
                  <th className={th}>Category</th>
                  <th className={cx(th, 'text-right')}>Sale price</th>
                  {showCost && <th className={cx(th, 'text-right')}>Avg cost</th>}
                  {showCost && <th className={cx(th, 'text-right')}>Margin</th>}
                  <th className={cx(th, 'text-right')}>Stock</th>
                  <th className={th} />
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {pageProducts.map((p) => {
                  const margin = p.salePrice > 0 && p.cost > 0 ? ((p.salePrice - p.cost) / p.salePrice) * 100 : null;
                  return (
                    <tr key={p.id} className={cx('hover:bg-slate-50', !p.active && 'opacity-50')}>
                      <td className={td}>
                        <div className="flex items-center gap-1.5 font-medium">
                          {p.favorite && <Star size={13} className="fill-amber-400 text-amber-400" />}
                          {p.name}
                        </div>
                        <div className="text-xs text-slate-500">
                          {p.sku}
                          {p.barcode && ` · ${p.barcode}`}
                          {p.nameUr && <span className="urdu mr-2"> {p.nameUr}</span>}
                        </div>
                      </td>
                      <td className={cx(td, 'text-slate-600')}>{catName(p.categoryId)}</td>
                      <td className={cx(td, 'text-right tabular-nums')}>
                        {rs(p.salePrice)}
                        <span className="text-xs text-slate-400"> /{p.unit}</span>
                      </td>
                      {showCost && <td className={cx(td, 'text-right tabular-nums text-slate-600')}>{rs(p.cost)}</td>}
                      {showCost && (
                        <td className={cx(td, 'text-right tabular-nums', margin !== null && margin < 5 ? 'text-rose-600' : 'text-slate-600')}>
                          {margin === null ? '—' : `${margin.toFixed(1)}%`}
                        </td>
                      )}
                      <td className={cx(td, 'text-right tabular-nums')}>
                        <span className={cx(p.stock <= 0 ? 'text-rose-600 font-semibold' : p.stock <= p.minStock ? 'text-amber-600 font-semibold' : '')}>
                          {qty(p.stock)}
                        </span>{' '}
                        <span className="text-xs text-slate-400">{p.unit}</span>
                      </td>
                      <td className={cx(td, 'whitespace-nowrap text-right')}>
                        <VoiceKeywordMic
                          productName={p.name}
                          onKeyword={async (keyword) => {
                            const current = await db.products.get(p.id);
                            if (!current) throw new Error('Product no longer exists');
                            const keywords = current.voiceKeywords ?? [];
                            if (keywords.some((saved) => saved.trim().toLocaleLowerCase() === keyword.toLocaleLowerCase())) {
                              return `Already learned for ${p.name}: ${keyword}`;
                            }
                            await db.products.update(p.id, { voiceKeywords: [...keywords, keyword] });
                            return `Learned for ${p.name}: ${keyword}`;
                          }}
                        />
                        <Button
                          size="sm"
                          variant="ghost"
                          title={p.favorite ? 'Remove from favorites' : 'Add to favorites'}
                          aria-label={p.favorite ? `Remove ${p.name} from favorites` : `Add ${p.name} to favorites`}
                          onClick={() => run(() => db.products.update(p.id, { favorite: !p.favorite }), p.favorite ? 'Removed from favorites' : 'Added to favorites')}
                        >
                          <Star size={15} className={p.favorite ? 'fill-amber-400 text-amber-400' : ''} />
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => setAdjusting(p)} title="Adjust stock">
                          <Boxes size={15} />
                        </Button>
                        <Button size="sm" variant="ghost" onClick={() => setEditing(p)} title="Edit">
                          <Pencil size={15} />
                        </Button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        {list.length > 0 && (
          <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 px-3 py-2 text-sm text-slate-600">
            <span>Showing {firstVisible}–{lastVisible} of {list.length} products</span>
            <div className="flex items-center gap-2">
              <Button size="sm" variant="secondary" disabled={visiblePage === 0} onClick={() => setPage(visiblePage - 1)}>
                Previous
              </Button>
              <span className="tabular-nums">Page {visiblePage + 1} of {pageCount}</span>
              <Button size="sm" variant="secondary" disabled={visiblePage >= pageCount - 1} onClick={() => setPage(visiblePage + 1)}>
                Next
              </Button>
            </div>
          </div>
        )}
      </Card>
      {editing && (
        <ProductForm
          product={editing === 'new' ? null : editing}
          categories={categories}
          suppliers={suppliers}
          showCost={showCost}
          canEditPrices={can('priceEdit')}
          onClose={() => setEditing(null)}
        />
      )}
      {adjusting && <StockAdjustModal product={adjusting} onClose={() => setAdjusting(null)} />}
      {managingCats && <CategoriesModal onClose={() => setManagingCats(false)} />}
    </div>
  );
}

export function ProductForm({
  product,
  categories,
  suppliers,
  showCost,
  canEditPrices,
  initialSupplierId,
  onCreated,
  onClose,
}: {
  product: Product | null;
  categories: { id: string; name: string }[];
  suppliers: { id: string; name: string }[];
  showCost: boolean;
  canEditPrices: boolean;
  initialSupplierId?: string;
  onCreated?: (productId: string) => void | Promise<void>;
  onClose: () => void;
}) {
  const run = useAction();
  const toast = useToast();
  const [voiceKeywordDraft, setVoiceKeywordDraft] = useState('');
  const [f, setF] = useState(() => ({
    name: product?.name ?? '',
    nameUr: product?.nameUr ?? '',
    voiceKeywords: product?.voiceKeywords ?? [],
    sku: product?.sku ?? '',
    barcode: product?.barcode ?? '',
    categoryId: product?.categoryId ?? '',
    supplierId: product?.supplierId ?? initialSupplierId ?? '',
    unit: product?.unit ?? 'Piece',
    packName: product?.packName ?? 'Carton',
    packSize: product?.packSize ? String(product.packSize) : '',
    salePrice: product?.salePrice ?? 0,
    thresholdPrice: product?.thresholdPrice == null ? '' : String(product.thresholdPrice / 100),
    wholesalePrice: product?.wholesalePrice == null ? '' : String(product.wholesalePrice / 100),
    cost: product?.cost ?? 0,
    minStock: product ? String(product.minStock) : '0',
    openingStock: '',
    favorite: product?.favorite ?? false,
    active: product?.active ?? true,
  }));
  const set = <K extends keyof typeof f>(k: K, v: (typeof f)[K]) => setF((x) => ({ ...x, [k]: v }));
  const appendVoiceKeywords = (text: string) => {
    const existing = new Set(f.voiceKeywords.map((keyword) => keyword.trim().toLocaleLowerCase()));
    const added: string[] = [];
    for (const keyword of text.split(/[;,|]/).map((part) => part.trim()).filter(Boolean)) {
      const key = keyword.toLocaleLowerCase();
      if (!existing.has(key)) {
        existing.add(key);
        added.push(keyword);
      }
    }
    if (added.length) set('voiceKeywords', [...f.voiceKeywords, ...added]);
    return added;
  };

  const save = () =>
    run(async () => {
      if (!f.name.trim()) throw new Error('Enter product name');
      if (f.salePrice <= 0) throw new Error('Enter sale price');
      const thresholdPrice = f.thresholdPrice.trim() ? Math.round(Number(f.thresholdPrice) * 100) : undefined;
      if (thresholdPrice !== undefined && (!Number.isFinite(thresholdPrice) || thresholdPrice < 0 || thresholdPrice > f.salePrice)) throw new Error('Threshold price must be between zero and the normal sale price');
      const wholesalePrice = f.wholesalePrice.trim() ? Math.round(Number(f.wholesalePrice) * 100) : undefined;
      if (wholesalePrice !== undefined && (!Number.isFinite(wholesalePrice) || wholesalePrice < 0)) throw new Error('Wholesale price must be zero or greater');
      const sku = f.sku.trim() || `P${Date.now().toString().slice(-6)}`;
      const dupe = await db.products.where('sku').equals(sku).first();
      if (dupe && dupe.id !== product?.id) throw new Error(`SKU ${sku} is already used by ${dupe.name}`);
      if (f.barcode.trim()) {
        const b = await db.products.where('barcode').equals(f.barcode.trim()).first();
        if (b && b.id !== product?.id) throw new Error(`Barcode already used by ${b.name}`);
      }
      const data = {
        name: f.name.trim(),
        nameUr: f.nameUr.trim() || undefined,
        voiceKeywords: f.voiceKeywords,
        sku,
        barcode: f.barcode.trim() || undefined,
        categoryId: f.categoryId || undefined,
        supplierId: f.supplierId || undefined,
        unit: f.unit,
        packName: f.packSize ? f.packName : undefined,
        packSize: f.packSize ? Number(f.packSize) : undefined,
        salePrice: f.salePrice,
        thresholdPrice,
        wholesalePrice,
        minStock: Number(f.minStock) || 0,
        favorite: f.favorite,
        active: f.active,
      };
      if (product) {
        await db.products.update(product.id, { ...data, ...(showCost ? { cost: f.cost } : {}) });
      } else {
        const id = uid();
        await db.products.add({ ...data, id, cost: f.cost, stock: 0, createdAt: nowIso() });
        const opening = Number(f.openingStock);
        if (opening > 0) await adjustStock({ productId: id, qty: opening, type: 'opening', cost: f.cost, note: 'Opening stock' });
        await onCreated?.(id);
      }
      onClose();
    }, product ? 'Product updated' : 'Product added');

  return (
    <Modal
      wide
      title={product ? `Edit ${product.name}` : 'Add product'}
      onClose={onClose}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={save}>Save</Button>
        </>
      }
    >
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Product name *">
          <Input value={f.name} onChange={(e) => set('name', e.target.value)} autoFocus />
        </Field>
        <Field label="Urdu name">
          <Input className="urdu" value={f.nameUr} onChange={(e) => set('nameUr', e.target.value)} />
        </Field>
        <Field label="Voice keywords" hint="Each saved name appears below. Type one or more separated by commas, or record with the mic; Save the product to keep changes." className="sm:col-span-2">
          <div className="flex flex-wrap gap-1.5">
            {f.voiceKeywords.map((keyword, index) => (
              <span key={`${keyword}-${index}`} className="inline-flex max-w-full items-center gap-1 rounded-md border border-sky-200 bg-sky-50 py-0.5 pr-0.5 pl-2 text-sm text-sky-900">
                <span className="break-all">{keyword}</span>
                <button
                  type="button"
                  className="rounded p-1 text-sky-700 hover:bg-sky-100"
                  title={`Remove keyword ${keyword}`}
                  aria-label={`Remove voice keyword ${keyword}`}
                  onClick={() => set('voiceKeywords', f.voiceKeywords.filter((_, itemIndex) => itemIndex !== index))}
                >
                  <X size={13} />
                </button>
              </span>
            ))}
          </div>
          <div className="mt-2 flex items-center gap-2">
            <Input
              className="flex-1"
              value={voiceKeywordDraft}
              onChange={(e) => setVoiceKeywordDraft(e.target.value)}
              onKeyDown={(event) => {
                if (event.key === 'Enter') {
                  event.preventDefault();
                  const added = appendVoiceKeywords(voiceKeywordDraft);
                  if (added.length) {
                    setVoiceKeywordDraft('');
                    toast(`Added ${added.length} voice keyword${added.length === 1 ? '' : 's'}. Save the product to keep changes.`);
                  }
                }
              }}
              placeholder="e.g. cheeni, meetha, چینی"
            />
            <Button
              size="sm"
              variant="secondary"
              disabled={!voiceKeywordDraft.trim()}
              title="Add typed voice keyword"
              aria-label="Add typed voice keyword"
              onClick={() => {
                const added = appendVoiceKeywords(voiceKeywordDraft);
                if (added.length) {
                  setVoiceKeywordDraft('');
                  toast(`Added ${added.length} voice keyword${added.length === 1 ? '' : 's'}. Save the product to keep changes.`);
                }
              }}
            >
              <Plus size={16} /> Add
            </Button>
            <VoiceKeywordMic
              productName={f.name || 'this product'}
              onKeyword={(keyword) => {
                const added = appendVoiceKeywords(keyword);
                return added.length ? `Added "${keyword}". Save the product to keep it.` : `Already in the keyword list: ${keyword}`;
              }}
            />
          </div>
        </Field>
        <Field label="SKU / code" hint="Leave empty to generate">
          <Input value={f.sku} onChange={(e) => set('sku', e.target.value)} />
        </Field>
        <Field label="Barcode" hint="Scan with a barcode scanner or type">
          <Input value={f.barcode} onChange={(e) => set('barcode', e.target.value)} />
        </Field>
        <Field label="Category">
          <Select value={f.categoryId} onChange={(e) => set('categoryId', e.target.value)}>
            <option value="">—</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Main supplier">
          <Select value={f.supplierId} onChange={(e) => set('supplierId', e.target.value)}>
            <option value="">—</option>
            {suppliers.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </Select>
        </Field>
        <Field label="Sale unit" hint="Stock is counted in this unit">
          <Select value={f.unit} onChange={(e) => set('unit', e.target.value)}>
            {UNITS.map((u) => (
              <option key={u}>{u}</option>
            ))}
          </Select>
        </Field>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Buying pack">
            <Select value={f.packName} onChange={(e) => set('packName', e.target.value)}>
              {['Carton', 'Box', 'Case', 'Crate', 'Sack', 'Dozen', 'Tray', 'Bundle'].map((u) => (
                <option key={u}>{u}</option>
              ))}
            </Select>
          </Field>
          <Field label={`${f.unit}s per pack`}>
            <Input inputMode="decimal" value={f.packSize} onChange={(e) => set('packSize', e.target.value)} placeholder="e.g. 24" />
          </Field>
        </div>
        <Field label={`Sale price per ${f.unit} (Rs) *`}>
          <MoneyInput value={f.salePrice} onChange={(v) => set('salePrice', v)} />
        </Field>
        <Field label={`Threshold special price per ${f.unit} (Rs)`} hint="Used instead of percentage discounts on a threshold-qualified bill; normal sale price remains unchanged">
          <Input inputMode="decimal" min="0" max={f.salePrice / 100} value={f.thresholdPrice} onChange={(event) => set('thresholdPrice', event.target.value)} placeholder="Optional" disabled={!canEditPrices} />
        </Field>
        <Field label={`Shopkeeper/wholesale price per ${f.unit} (Rs)`} hint="Used only after Shopkeeper Rate is confirmed">
          <Input inputMode="decimal" min="0" value={f.wholesalePrice} onChange={(event) => set('wholesalePrice', event.target.value)} placeholder="Optional" disabled={!canEditPrices} />
        </Field>
        {(showCost || !product) && (
          <Field label={`Purchase cost per ${f.unit} (Rs)`} hint={product ? 'Updated automatically by purchases' : undefined}>
            <MoneyInput value={f.cost} onChange={(v) => set('cost', v)} />
          </Field>
        )}
        <Field label="Minimum stock" hint="Alert when stock falls to this level">
          <Input inputMode="decimal" value={f.minStock} onChange={(e) => set('minStock', e.target.value)} />
        </Field>
        {!product && (
          <Field label="Opening stock" hint={`How many ${f.unit}s you have now`}>
            <Input inputMode="decimal" value={f.openingStock} onChange={(e) => set('openingStock', e.target.value)} />
          </Field>
        )}
        <div className="flex items-center gap-6 sm:col-span-2">
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={f.favorite} onChange={(e) => set('favorite', e.target.checked)} /> Show in POS favourites
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={f.active} onChange={(e) => set('active', e.target.checked)} /> Active
          </label>
        </div>
      </div>
    </Modal>
  );
}

function VoiceKeywordMic({ productName, onKeyword }: { productName: string; onKeyword: (keyword: string) => string | void | Promise<string | void> }) {
  const toast = useToast();
  const [lang] = useVoiceLang();
  const speech = useSpeech(
    lang,
    (transcript) => {
      const keyword = transcript.trim();
      if (!keyword) return;
      void Promise.resolve(onKeyword(keyword))
        .then((message) => toast(message ?? `Learned "${keyword}" for ${productName}`))
        .catch((error: unknown) => toast(error instanceof Error ? error.message : 'Could not save voice keyword', 'error'));
    },
    (message) => toast(message, 'error'),
  );
  const listening = speech.state === 'listening' || speech.state === 'processing';

  return (
    <Button
      size="sm"
      variant={listening ? 'danger' : 'ghost'}
      title={listening ? `Stop recording for ${productName}` : `Record a voice name for ${productName}`}
      aria-label={listening ? `Stop recording for ${productName}` : `Record a voice name for ${productName}`}
      disabled={speech.state === 'processing'}
      onClick={() => listening ? speech.stop() : speech.start()}
    >
      <Mic size={16} />
      {listening ? 'Stop' : null}
    </Button>
  );
}

function StockAdjustModal({ product, onClose }: { product: Product; onClose: () => void }) {
  const run = useAction();
  const [mode, setMode] = useState<'add' | 'remove' | 'set'>('add');
  const [type, setType] = useState<'adjust' | 'damage' | 'expiry'>('adjust');
  const [amount, setAmount] = useState('');
  const [cost, setCost] = useState(product.cost);
  const [note, setNote] = useState('');
  const moves = useLiveQuery(() => db.stockMoves.where('productId').equals(product.id).reverse().sortBy('date'), [product.id]) ?? [];
  const n = Number(amount) || 0;
  const delta = mode === 'add' ? n : mode === 'remove' ? -n : n - product.stock;

  return (
    <Modal
      wide
      title={`Stock — ${product.name}`}
      onClose={onClose}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Close
          </Button>
          <Button
            disabled={delta === 0 || !amount}
            onClick={() =>
              run(async () => {
                await adjustStock({
                  productId: product.id,
                  qty: delta,
                  type: delta < 0 ? type : 'adjust',
                  ...(delta > 0 ? { cost } : {}),
                  note: note || (mode === 'set' ? 'Stock count correction' : undefined),
                });
                onClose();
              }, 'Stock updated')
            }
          >
            Save adjustment
          </Button>
        </>
      }
    >
      <p className="mb-3 text-sm text-slate-600">
        Current stock: <b>{qty(product.stock)} {product.unit}</b>. Every change is recorded with a reason.
      </p>
      <div className="mb-3 flex gap-2">
        {(['add', 'remove', 'set'] as const).map((m) => (
          <Button key={m} size="sm" variant={mode === m ? 'primary' : 'secondary'} onClick={() => setMode(m)}>
            {m === 'add' ? 'Add stock' : m === 'remove' ? 'Remove stock' : 'Set counted stock'}
          </Button>
        ))}
      </div>
      <div className="grid gap-3 sm:grid-cols-3">
        <Field label={mode === 'set' ? `Counted ${product.unit}s` : `Quantity (${product.unit})`}>
          <Input inputMode="decimal" value={amount} onChange={(e) => setAmount(e.target.value)} autoFocus />
        </Field>
        {delta < 0 && (
          <Field label="Reason">
            <Select value={type} onChange={(e) => setType(e.target.value as typeof type)}>
              <option value="adjust">Correction / missing</option>
              <option value="damage">Damaged</option>
              <option value="expiry">Expired</option>
            </Select>
          </Field>
        )}
        {delta > 0 && (
          <Field label="Cost per unit (Rs)">
            <MoneyInput value={cost} onChange={setCost} />
          </Field>
        )}
        <Field label="Note">
          <Input value={note} onChange={(e) => setNote(e.target.value)} />
        </Field>
      </div>
      {delta !== 0 && amount && (
        <p className="mt-2 text-sm">
          Change: <b className={delta > 0 ? 'text-emerald-600' : 'text-rose-600'}>{delta > 0 ? '+' : ''}{qty(delta)}</b> → new stock{' '}
          <b>{qty(product.stock + delta)}</b>
        </p>
      )}
      <h4 className="mt-5 mb-2 text-sm font-semibold">Stock history</h4>
      <MovesTable moves={moves.slice(0, 30)} unit={product.unit} />
    </Modal>
  );
}

const MOVE_LABEL: Record<StockMove['type'], string> = {
  opening: 'Opening',
  sale: 'Sale',
  return: 'Return',
  purchase: 'Purchase',
  purchase_return: 'Purchase return',
  adjust: 'Adjustment',
  damage: 'Damaged',
  expiry: 'Expired',
};

export function MovesTable({ moves, unit }: { moves: StockMove[]; unit: string }) {
  if (moves.length === 0) return <p className="text-sm text-slate-500">No stock movements yet.</p>;
  return (
    <table className="w-full text-sm">
      <thead className="bg-slate-50">
        <tr>
          <th className={th}>Date</th>
          <th className={th}>Type</th>
          <th className={cx(th, 'text-right')}>Qty</th>
          <th className={th}>Note</th>
        </tr>
      </thead>
      <tbody className="divide-y divide-slate-100">
        {moves.map((m) => (
          <tr key={m.id}>
            <td className={td}>{new Date(m.date).toLocaleString('en-PK', { dateStyle: 'short', timeStyle: 'short' })}</td>
            <td className={td}>
              <Badge tone={m.qty > 0 ? 'green' : m.type === 'sale' ? 'blue' : 'red'}>{MOVE_LABEL[m.type]}</Badge>
            </td>
            <td className={cx(td, 'text-right tabular-nums', m.qty > 0 ? 'text-emerald-600' : 'text-rose-600')}>
              {m.qty > 0 ? '+' : ''}
              {qty(m.qty)} {unit}
            </td>
            <td className={cx(td, 'text-slate-500')}>{m.note}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function CategoriesModal({ onClose }: { onClose: () => void }) {
  const categories = useLiveQuery(() => db.categories.orderBy('name').toArray(), []) ?? [];
  const [name, setName] = useState('');
  const run = useAction();
  return (
    <Modal title="Categories" onClose={onClose}>
      <div className="mb-3 flex gap-2">
        <Input placeholder="New category" value={name} onChange={(e) => setName(e.target.value)} />
        <Button
          disabled={!name.trim()}
          onClick={async () => {
            await db.categories.add({ id: uid(), name: name.trim() });
            setName('');
          }}
        >
          Add
        </Button>
      </div>
      <ul className="divide-y divide-slate-100">
        {categories.map((c) => (
          <li key={c.id} className="flex items-center justify-between py-2 text-sm">
            <input
              className="flex-1 rounded px-1 py-0.5 hover:bg-slate-50"
              defaultValue={c.name}
              onBlur={(e) => e.target.value.trim() && db.categories.update(c.id, { name: e.target.value.trim() })}
            />
            <Button
              size="sm"
              variant="ghost"
              onClick={() =>
                run(async () => {
                  const used = await db.products.where('categoryId').equals(c.id).count();
                  if (used) throw new Error(`${used} products use this category`);
                  await db.categories.delete(c.id);
                })
              }
            >
              <Trash2 size={14} />
            </Button>
          </li>
        ))}
      </ul>
    </Modal>
  );
}
