import { Cloud } from 'lucide-react';
import { useState } from 'react';
import { Field, Input, Select } from '../components/ui';
import { loginWithPassword, type TenantChoice } from '../lib/api';
import { consumeIdleNotice, useSession } from '../lib/session';

/** Sign in with the email or mobile number and password of the shop account. */
export function Login() {
  const { signIn } = useSession();
  // Set by the idle auto-logout so people know why they are back here.
  const [error, setError] = useState(() => (consumeIdleNotice() ? 'You were signed out after 30 minutes without use.' : ''));
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [tenants, setTenants] = useState<TenantChoice[]>([]);
  const [tenantId, setTenantId] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setLoading(true);
    setError('');
    try {
      const result = await loginWithPassword({ identifier, password, ...(tenantId ? { tenantId } : {}) });
      if (result.status === 'choose_tenant') {
        setTenants(result.tenants);
        setTenantId(result.tenants.length === 1 ? result.tenants[0]!.tenantId : '');
      } else {
        setPassword('');
        signIn(result.session);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not sign in to the shop server');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-full items-center justify-center bg-slate-900 p-4">
      <div className="w-full max-w-sm rounded-xl bg-white p-6 shadow-xl">
        <div className="mb-4 text-center">
          <div className="mx-auto mb-2 grid h-12 w-12 place-items-center rounded-full bg-brand-50 text-brand-700">
            <Cloud />
          </div>
          <h1 className="text-xl font-bold">RetailOS</h1>
          <p className="text-sm text-slate-500">Sign in to your shop account</p>
        </div>
        <form className="grid gap-3" onSubmit={submit}>
          <Field label="Email or mobile">
            <Input autoComplete="username" value={identifier} onChange={(event) => setIdentifier(event.target.value)} required autoFocus />
          </Field>
          <Field label="Password">
            <Input type="password" autoComplete="current-password" value={password} onChange={(event) => setPassword(event.target.value)} required />
          </Field>
          {tenants.length > 0 && (
            <Field label="Shop">
              <Select value={tenantId} onChange={(event) => setTenantId(event.target.value)} required>
                <option value="">Choose shop</option>
                {tenants.map((tenant) => (
                  <option key={tenant.tenantId} value={tenant.tenantId}>
                    {tenant.name} · {tenant.role}
                  </option>
                ))}
              </Select>
            </Field>
          )}
          <p className="min-h-5 text-center text-sm text-rose-600" role="alert">
            {error}
          </p>
          <button
            type="submit"
            disabled={loading}
            className="inline-flex w-full items-center justify-center gap-2 rounded-lg bg-brand-600 px-5 py-3 text-base font-medium text-white hover:bg-brand-700 disabled:cursor-not-allowed disabled:bg-brand-600/50"
          >
            {loading ? 'Signing in…' : 'Sign in'}
          </button>
        </form>
      </div>
    </div>
  );
}
