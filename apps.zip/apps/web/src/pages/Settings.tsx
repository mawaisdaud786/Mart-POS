import { useLiveQuery } from '../lib/store';
import { Plus } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Badge, Button, Card, Field, Input, Modal, MoneyInput, PageHeader, Select, Textarea, cx, td, th, useAction } from '../components/ui';
import { db, uid, type Account, type Product, type VoiceLog } from '../lib/db';
import { BackupCard } from '../components/BackupCard';
import { TeamCard } from '../components/TeamCard';
import { rs } from '../lib/format';
import { useSession } from '../lib/session';

export function SettingsPage() {
  return (
    <div>
      <PageHeader title="Settings" />
      <div className="grid gap-4 xl:grid-cols-2">
        <ShopCard />
        <AccountsCard />
        <BackupCard />
        <TeamCard />
        <VoiceLogCard />
      </div>
    </div>
  );
}

function ShopCard() {
  const { settings } = useSession();
  const run = useAction();
  const categories = useLiveQuery(() => db.categories.orderBy('name').toArray(), []) ?? [];
  const [f, setF] = useState(settings);
  useEffect(() => setF(settings), [settings]);
  if (!f) return null;
  return (
    <Card title="Shop & receipt">
      <div className="grid gap-3 p-4 sm:grid-cols-2">
        <Field label="Shop name">
          <Input value={f.shopName} onChange={(e) => setF({ ...f, shopName: e.target.value })} />
        </Field>
        <Field label="Phone">
          <Input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
        </Field>
        <Field label="Address" className="sm:col-span-2">
          <Input value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} />
        </Field>
        <Field label="Receipt footer" className="sm:col-span-2">
          <Textarea rows={2} value={f.receiptFooter} onChange={(e) => setF({ ...f, receiptFooter: e.target.value })} />
        </Field>
        <Field label="Default supplier delivery days" hint="Used for reorder suggestions">
          <Input inputMode="numeric" value={f.leadDays} onChange={(e) => setF({ ...f, leadDays: Number(e.target.value) || 0 })} />
        </Field>
        <Field label="Cashier max discount (%)">
          <Input inputMode="decimal" value={f.cashierMaxDiscount} onChange={(e) => setF({ ...f, cashierMaxDiscount: Number(e.target.value) || 0 })} />
        </Field>
        <label className="flex items-center gap-2 text-sm sm:col-span-2">
          <input type="checkbox" checked={f.autoDiscountEnabled ?? true} onChange={(event) => setF({ ...f, autoDiscountEnabled: event.target.checked })} /> Enable automatic threshold discount
        </label>
        <Field label="Auto discount threshold (Rs)" hint="Threshold uses eligible item subtotal before discount">
          <MoneyInput value={f.autoDiscountMinOrder ?? 5000} onChange={(v) => setF({ ...f, autoDiscountMinOrder: v })} />
        </Field>
        <Field label="Default automatic discount (%)" hint="Applied when no product or category rule overrides it">
          <Input inputMode="decimal" min="0" max="100" value={f.autoDiscountPct ?? 10} onChange={(e) => setF({ ...f, autoDiscountPct: Number(e.target.value) || 0 })} />
        </Field>
        <Field label="Max auto discount (%)" hint="Hard cap, default 70%">
          <Input inputMode="decimal" min="0" max="100" value={f.autoDiscountMaxPct ?? 70} onChange={(e) => setF({ ...f, autoDiscountMaxPct: Number(e.target.value) || 0 })} />
        </Field>
        <div className="sm:col-span-2">
          <div className="mb-2 text-sm font-medium">Category discount rules</div>
          <div className="divide-y divide-slate-100 rounded border border-slate-200">
            {categories.map((category) => {
              const savedRule = (f.autoDiscountCategoryRules ?? []).find((rule) => rule.categoryId === category.id);
              const isLegacyTarget = f.autoDiscountCategoryId === category.id;
              const enabled = savedRule?.enabled ?? isLegacyTarget;
              const percent = savedRule?.percent ?? (isLegacyTarget ? f.autoDiscountPct : 0);
              const updateRule = (patch: Partial<{ enabled: boolean; percent: number }>) => {
                const current = f.autoDiscountCategoryRules ?? [];
                const rule = { categoryId: category.id, enabled, percent, ...patch };
                setF({ ...f, autoDiscountCategoryRules: [...current.filter((entry) => entry.categoryId !== category.id), rule] });
              };
              return <div key={category.id} className="grid grid-cols-[1fr_130px] items-center gap-3 px-3 py-2">
                <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={enabled} onChange={(event) => updateRule({ enabled: event.target.checked })} />{category.name}</label>
                <Input aria-label={`${category.name} discount percentage`} inputMode="decimal" min="0" max="100" value={percent} onChange={(event) => updateRule({ percent: Number(event.target.value) || 0 })} />
              </div>;
            })}
            {categories.length === 0 && <div className="px-3 py-2 text-sm text-slate-500">Add categories to configure category-specific discounts.</div>}
          </div>
        </div>
        <label className="flex items-center gap-2 text-sm sm:col-span-2">
          <input type="checkbox" checked={f.homeDeliveryEnabled ?? true} onChange={(event) => setF({ ...f, homeDeliveryEnabled: event.target.checked })} /> Enable home delivery
        </label>
        <Field label="Home delivery charge (Rs)"><MoneyInput value={f.deliveryCharge ?? f.gharDeliveryFee ?? 15000} onChange={(v) => setF({ ...f, deliveryCharge: v })} /></Field>
        <Field label="Free delivery threshold (Rs)"><MoneyInput value={f.freeDeliveryThreshold ?? f.gharFreeDeliveryThreshold ?? 400000} onChange={(v) => setF({ ...f, freeDeliveryThreshold: v })} /></Field>
        <label className="flex items-center gap-2 text-sm sm:col-span-2">
          <input type="checkbox" checked={f.businessPricingEnabled ?? true} onChange={(event) => setF({ ...f, businessPricingEnabled: event.target.checked })} /> Enable shopkeeper/business pricing (uses each product's wholesale price)
        </label>
        <Field label="Minimum product margin (%)" hint="Discounted prices will not go below this margin over cost">
          <Input inputMode="decimal" min="0" max="99" value={f.gharMinimumMarginPct ?? 10} onChange={(e) => setF({ ...f, gharMinimumMarginPct: Number(e.target.value) || 0 })} />
        </Field>
        <Field label="Home delivery fee (Rs)" hint="Charged when the discounted items subtotal is below the free-delivery threshold">
          <MoneyInput value={f.gharDeliveryFee ?? 15000} onChange={(v) => setF({ ...f, gharDeliveryFee: v })} />
        </Field>
        <Field label="Ghar discount and free delivery from (Rs)" hint="Ghar prices are discounted and delivery is free when regular-price items exceed this amount">
          <MoneyInput value={f.gharFreeDeliveryThreshold ?? 400000} onChange={(v) => setF({ ...f, gharFreeDeliveryThreshold: v })} />
        </Field>
        <Field label="Cash difference needing explanation (Rs)">
          <MoneyInput value={f.discrepancyLimit} onChange={(v) => setF({ ...f, discrepancyLimit: v })} />
        </Field>
        <div className="flex items-end">
          <Button onClick={() => run(async () => {
            const percentages = [f.autoDiscountPct, f.autoDiscountMaxPct, ...(f.autoDiscountCategoryRules ?? []).map((rule) => rule.percent)];
            if (percentages.some((value) => !Number.isFinite(value) || value < 0 || value > 100)) throw new Error('Discount percentages must be between 0 and 100');
            if (f.autoDiscountMinOrder < 0 || (f.deliveryCharge ?? 0) < 0 || (f.freeDeliveryThreshold ?? 0) < 0) throw new Error('Thresholds and delivery charges cannot be negative');
            const deliveryCharge = f.deliveryCharge ?? f.gharDeliveryFee ?? 15000;
            const freeDeliveryThreshold = f.freeDeliveryThreshold ?? f.gharFreeDeliveryThreshold ?? 400000;
            await db.settings.put({ ...f, autoDiscountCategoryId: 'all', gharDeliveryFee: deliveryCharge, gharFreeDeliveryThreshold: freeDeliveryThreshold });
          }, 'Settings saved')}>Save</Button>
        </div>
      </div>
    </Card>
  );
}

function AccountsCard() {
  const accounts = useLiveQuery(() => db.accounts.toArray(), []) ?? [];
  const run = useAction();
  const [name, setName] = useState('');
  const [type, setType] = useState<Account['type']>('bank');
  return (
    <Card title="Payment accounts">
      <ul className="divide-y divide-slate-100">
        {accounts.map((a) => (
          <li key={a.id} className="flex items-center justify-between gap-2 px-4 py-2 text-sm">
            <input
              className="flex-1 rounded px-1 py-0.5 hover:bg-slate-50"
              defaultValue={a.name}
              onBlur={(e) => e.target.value.trim() && db.accounts.update(a.id, { name: e.target.value.trim() })}
            />
            <span className="text-xs capitalize text-slate-500">
              {a.type}
              {a.provider && ' · retailer'}
            </span>
            {a.type !== 'cash' && (
              <label className="flex items-center gap-1 text-xs">
                <input type="checkbox" checked={a.active} onChange={(e) => db.accounts.update(a.id, { active: e.target.checked })} /> Active
              </label>
            )}
          </li>
        ))}
      </ul>
      <div className="flex gap-2 border-t border-slate-100 p-3">
        <Input placeholder="New account, e.g. Meezan Bank" value={name} onChange={(e) => setName(e.target.value)} />
        <Select className="w-32" value={type} onChange={(e) => setType(e.target.value as Account['type'])}>
          <option value="bank">Bank</option>
          <option value="wallet">Wallet</option>
          <option value="cash">Cash</option>
        </Select>
        <Button
          disabled={!name.trim()}
          onClick={() =>
            run(async () => {
              await db.accounts.add({ id: uid(), name: name.trim(), type, active: true });
              setName('');
            }, 'Account added')
          }
        >
          Add
        </Button>
      </div>
    </Card>
  );
}

/** Last voice commands, for checking what the assistant heard and understood. */
function VoiceLogCard() {
  const logs = useLiveQuery(() => db.voiceLogs.orderBy('date').reverse().limit(25).toArray(), []) ?? [];
  const products = useLiveQuery(() => db.products.orderBy('name').toArray(), []) ?? [];
  const [correcting, setCorrecting] = useState<VoiceLog | null>(null);
  const run = useAction();

  const saveCorrection = (productId: string, phrase: string) => {
    if (!correcting) return;
    return run(async () => {
      const keyword = phrase.trim();
      if (!keyword) throw new Error('Enter the phrase the customer meant');
      await db.transaction('rw', db.products, db.voiceLogs, async () => {
        const [product, log] = await Promise.all([db.products.get(productId), db.voiceLogs.get(correcting.id)]);
        if (!product || !log) throw new Error('Product or voice log no longer exists');
        const keywords = product.voiceKeywords ?? [];
        if (!keywords.some((saved) => saved.trim().toLocaleLowerCase() === keyword.toLocaleLowerCase())) {
          await db.products.update(product.id, { voiceKeywords: [...keywords, keyword] });
        }
        await db.voiceLogs.update(log.id, {
          correctedProductId: product.id,
          correctionPhrase: keyword,
          correctedAt: new Date().toISOString(),
          productIds: [...new Set([...log.productIds, product.id])],
        });
      });
      setCorrecting(null);
    }, 'Voice vocabulary improved');
  };

  return (
    <Card title="Voice command log" className="xl:col-span-2">
      {logs.length === 0 ? (
        <p className="p-4 text-sm text-slate-500">No voice commands yet. Audio is never saved — only the recognised text.</p>
      ) : (
        <div className="max-h-96 overflow-y-auto">
          <table className="w-full">
            <thead className="bg-slate-50">
              <tr>
                <th className={th}>Time</th>
                <th className={th}>Heard</th>
                <th className={th}>Understood as</th>
                <th className={th}>Result</th>
                <th className={th} />
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {logs.map((l) => {
                const correctedProduct = products.find((product) => product.id === l.correctedProductId);
                return (
                  <tr key={l.id}>
                    <td className={cx(td, 'whitespace-nowrap text-slate-600')}>{new Date(l.date).toLocaleString('en-PK', { dateStyle: 'short', timeStyle: 'short' })}</td>
                    <td className={td}>{l.spokenText}</td>
                    <td className={cx(td, 'font-mono text-xs text-slate-600')}>{JSON.stringify(l.parsed)}</td>
                    <td className={td}>
                      <div className="flex flex-wrap items-center gap-1.5">
                        <Badge tone={l.status === 'success' ? 'green' : l.status === 'partial' ? 'amber' : 'red'}>{l.status}</Badge>
                        {l.correctedProductId && <Badge tone="blue">Vocabulary improved</Badge>}
                      </div>
                      {l.correctedProductId && (
                        <p className="mt-1 text-xs text-slate-600">
                          Meant: <b>{correctedProduct?.name ?? 'Product'}</b> · learned “{l.correctionPhrase}”
                        </p>
                      )}
                    </td>
                    <td className={cx(td, 'text-right')}>
                      <Button size="sm" variant="secondary" onClick={() => setCorrecting(l)}>
                        <Plus size={14} /> {l.correctedProductId ? 'Edit correction' : 'What did you mean?'}
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
      {correcting && (
        <VoiceCorrectionModal
          key={correcting.id}
          log={correcting}
          products={products}
          onClose={() => setCorrecting(null)}
          onSave={saveCorrection}
        />
      )}
    </Card>
  );
}

function VoiceCorrectionModal({
  log,
  products,
  onClose,
  onSave,
}: {
  log: VoiceLog;
  products: Product[];
  onClose: () => void;
  onSave: (productId: string, phrase: string) => void;
}) {
  const parsed = log.parsed as { items?: { spoken_name?: string }[] } | null;
  const defaultPhrase = parsed?.items?.length === 1 ? parsed.items[0]?.spoken_name ?? log.spokenText : log.spokenText;
  const [phrase, setPhrase] = useState(log.correctionPhrase ?? defaultPhrase);
  const [query, setQuery] = useState('');
  const [selectedProductId, setSelectedProductId] = useState(log.correctedProductId ?? '');
  const search = query.trim().toLocaleLowerCase();
  const matches = products
    .filter((product) => !search || [product.name, product.nameUr, product.sku, product.barcode, ...(product.voiceKeywords ?? [])]
      .some((value) => value?.toLocaleLowerCase().includes(search)))
    .slice(0, 10);
  const selected = products.find((product) => product.id === selectedProductId);

  return (
    <Modal
      title="Improve voice vocabulary"
      onClose={onClose}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>Cancel</Button>
          <Button disabled={!selectedProductId || !phrase.trim()} onClick={() => onSave(selectedProductId, phrase)}>
            Save correction
          </Button>
        </>
      }
    >
      <div className="space-y-3">
        <div className="rounded-md bg-slate-50 p-3 text-sm">
          <div className="mb-1 text-xs font-semibold uppercase text-slate-500">Voice log heard</div>
          <div>{log.spokenText}</div>
        </div>
        <Field label="What phrase should match the product?" hint="Use just the product name or nickname, not the whole command if it included quantity or payment.">
          <Input value={phrase} onChange={(event) => setPhrase(event.target.value)} autoFocus />
        </Field>
        <Field label="Which product did you mean?">
          <Input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search product name, SKU or keyword" />
        </Field>
        {selected && (
          <p className="text-sm text-emerald-700">Selected: <b>{selected.name}</b> · {selected.unit} · {rs(selected.salePrice)}</p>
        )}
        <div className="max-h-56 overflow-y-auto divide-y divide-slate-100 rounded-md border border-slate-200">
          {matches.map((product) => (
            <button
              key={product.id}
              type="button"
              className={cx('flex w-full items-center justify-between gap-3 px-3 py-2 text-left text-sm hover:bg-slate-50', selectedProductId === product.id && 'bg-emerald-50')}
              onClick={() => setSelectedProductId(product.id)}
            >
              <span className="min-w-0">
                <span className="font-medium">{product.name}</span>
                <span className="ml-2 text-xs text-slate-500">{product.sku} · {product.unit}</span>
              </span>
              <span className="shrink-0 text-slate-600">{rs(product.salePrice)}{!product.active && <Badge>Inactive</Badge>}</span>
            </button>
          ))}
          {matches.length === 0 && <p className="p-3 text-sm text-slate-500">No products match that search.</p>}
        </div>
      </div>
    </Modal>
  );
}
