import { useLiveQuery } from '../lib/store';
import { Home, Keyboard, Minus, PauseCircle, Plus, Search, ShoppingCart, Star, Trash2, Truck } from 'lucide-react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useLocation, useNavigate } from 'react-router';
import { CustomerPicker } from '../components/CustomerPicker';
import { ReceiptModal } from '../components/Receipt';
import { useVoiceAssistant } from '../components/VoiceAssistant';
import { Badge, Button, Empty, Field, Input, Modal, MoneyInput, cx, useAction, useToast } from '../components/ui';
import { ACCOUNT_IDS, db, nowIso, uid, type GharOrder, type Product, type Sale, type SaleItem } from '../lib/db';
import { lineTotal, qty as fmtQty, roundQty, rs } from '../lib/format';
import { OpError, cartSubtotal, completeSale } from '../lib/ops';
import { partyBalances, salesVelocity as salesVelocity30 } from '../lib/reports';
import { useSession, useUser } from '../lib/session';
import { calculatePricing } from '@retailos/domain';

type CartLine = Omit<SaleItem, 'cost' | 'returnedQty'>;

export function PosPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const user = useUser();
  const { settings, can, has } = useSession();
  const toast = useToast();
  const run = useAction();
  const products = useLiveQuery(() => db.products.filter((p) => p.active).toArray(), []) ?? [];
  const categories = useLiveQuery(() => db.categories.orderBy('name').toArray(), []) ?? [];
  const held = useLiveQuery(() => db.heldCarts.toArray(), []) ?? [];
  const salesCutoff = useMemo(() => new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(), []);
  // Units sold per product in the last 30 days (added up by the server) rank the product grid.
  const velocity = useLiveQuery(() => salesVelocity30(salesCutoff).catch(() => ({}) as Record<string, number>), [salesCutoff]) ?? {};
  const salesVelocity = useMemo(() => new Map(Object.entries(velocity)), [velocity]);

  const [search, setSearch] = useState('');
  const [category, setCategory] = useState<string>('all');
  const [cart, setCart] = useState<CartLine[]>([]);
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [discount, setDiscount] = useState(0);
  const [deliveryFee, setDeliveryFee] = useState(0);
  const [gharOrderId, setGharOrderId] = useState<string | undefined>();
  const [gharQuoteMode, setGharQuoteMode] = useState(false);
  const [homeDelivery, setHomeDelivery] = useState(false);
  const [gharAddress, setGharAddress] = useState('');
  const [gharNote, setGharNote] = useState('');
  const [gharQuoteError, setGharQuoteError] = useState('');
  const [gharQuotePending, setGharQuotePending] = useState(false);
  const [businessPricing, setBusinessPricing] = useState(false);
  const [confirmBusinessPricing, setConfirmBusinessPricing] = useState(false);
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [customerId, setCustomerId] = useState<string | undefined>();
  const [customerFocusRequest, setCustomerFocusRequest] = useState(0);
  const [paying, setPaying] = useState(false);
  const [receipt, setReceipt] = useState<Sale | null>(null);
  const [showHeld, setShowHeld] = useState(false);
  /** Udhaar opens payment with no cash, so the whole bill goes on the customer's khata. */
  const [paymentMode, setPaymentMode] = useState<'cash' | 'credit'>('cash');
  const [removedCreditDiscount, setRemovedCreditDiscount] = useState(0);
  const billCustomer = useLiveQuery(() => (customerId ? db.customers.get(customerId) : undefined), [customerId]);
  const searchRef = useRef<HTMLInputElement>(null);
  const gharQuoteRequest = useRef(0);
  const cartLineRefs = useRef(new Map<string, HTMLLIElement>());
  const [lastAddedProductId, setLastAddedProductId] = useState<string | null>(null);
  const pricing = useMemo(() => {
    if (!settings || gharQuoteMode || gharOrderId || cart.length === 0) return null;
    return calculatePricing({
      lines: cart.map(({ productId, qty, price }) => ({ productId, qty, ...(price !== products.find((product) => product.id === productId)?.salePrice ? { price } : {}) })),
      products: products.map((product) => ({ id: product.id, salePrice: product.salePrice, thresholdPrice: product.thresholdPrice, wholesalePrice: product.wholesalePrice, categoryId: product.categoryId })),
      settings: {
        autoDiscountEnabled: settings.autoDiscountEnabled ?? true,
        threshold: settings.autoDiscountMinOrder,
        defaultPercent: settings.autoDiscountPct,
        maxPercent: settings.autoDiscountMaxPct,
        categoryRules: settings.autoDiscountCategoryRules?.length
          ? settings.autoDiscountCategoryRules
          : settings.autoDiscountCategoryId && settings.autoDiscountCategoryId !== 'all'
            ? [{ categoryId: settings.autoDiscountCategoryId, percent: settings.autoDiscountPct, enabled: true }]
            : [],
        deliveryEnabled: settings.homeDeliveryEnabled ?? true,
        deliveryCharge: settings.deliveryCharge ?? settings.gharDeliveryFee ?? 0,
        freeDeliveryThreshold: settings.freeDeliveryThreshold ?? settings.gharFreeDeliveryThreshold ?? 0,
        businessPricingEnabled: settings.businessPricingEnabled ?? true,
      },
      pricingMode: businessPricing ? 'business' : 'normal',
      paymentMethod: paymentMode,
      homeDelivery,
    });
  }, [settings, gharQuoteMode, gharOrderId, cart, products, businessPricing, paymentMode, homeDelivery]);
  const lineDiscountTotal = pricing?.discountAmount ?? 0;
  const subtotal = pricing ? pricing.subtotal : cartSubtotal(cart);
  const rawSubtotal = pricing?.eligibleSubtotal ?? cart.reduce((sum, line) => sum + Math.round(line.price * line.qty), 0);
  const activeDeliveryFee = pricing?.deliveryCharge ?? (gharQuoteMode || gharOrderId ? deliveryFee : 0);
  const total = subtotal - lineDiscountTotal - discount + activeDeliveryFee;

  useEffect(() => {
    if (homeDelivery) {
      const address = billCustomer?.address ?? '';
      setDeliveryAddress(address);
      if (gharQuoteMode) setGharAddress(address);
    }
  }, [gharQuoteMode, homeDelivery, customerId, billCustomer?.address]);

  const visible = useMemo(() => {
    const s = search.trim().toLowerCase();
    let list = products;
    if (s) {
      list = list.filter(
        (p) => p.name.toLowerCase().includes(s) || p.sku.toLowerCase() === s || p.barcode === s || p.nameUr?.includes(search.trim()),
      );
    } else if (category === 'fav') {
      list = list.filter((p) => p.favorite);
      if (list.length === 0) list = products;
    } else if (category !== 'all') {
      list = list.filter((p) => p.categoryId === category);
    }
    if (!s && category === 'all') {
      return [...list]
        .sort((a, b) => (salesVelocity.get(b.id) ?? 0) - (salesVelocity.get(a.id) ?? 0) || a.name.localeCompare(b.name))
        .slice(0, 20);
    }
    return [...list].sort((a, b) => a.name.localeCompare(b.name)).slice(0, 60);
  }, [products, search, category, salesVelocity]);

  const stockVisibleToThisCart = (product: Product) => product.stock;

  /** Most of a product that can go on this bill: what is on the shelf (untracked products have no limit). */
  const maxCartQuantity = (product: Product, _currentQty: number) => (product.trackStock === false ? Number.POSITIVE_INFINITY : Math.max(0, product.stock));

  const addProduct = useCallback(
    (p: Product, q = 1) => {
      if (gharOrderId) return;
      const inCurrentCart = cart.find((line) => line.productId === p.id)?.qty ?? 0;
      const maxQty = maxCartQuantity(p, inCurrentCart);
      if (inCurrentCart + q > maxQty) {
        toast(`${p.name}: only ${fmtQty(Math.max(0, maxQty - inCurrentCart))} more available`, 'error');
        return;
      }
      setLastAddedProductId(p.id);
      setCart((c) => {
        const existing = c.find((l) => l.productId === p.id);
        if (existing) return c.map((l) => (l.productId === p.id ? { ...l, qty: roundQty(l.qty + q) } : l));
        return [...c, { productId: p.id, name: p.name, unit: p.unit, qty: q, price: p.salePrice, discount: 0 }];
      });
    },
    [gharOrderId, cart, toast],
  );

  /** Enter in the search box: exact barcode/SKU first (USB scanners type the code + Enter), else first match. */
  const onSearchEnter = () => {
    const s = search.trim();
    if (!s) return;
    const exact = products.find((p) => p.barcode === s || p.sku.toLowerCase() === s.toLowerCase());
    const pick = exact ?? (visible.length === 1 ? visible[0] : undefined);
    if (pick) {
      addProduct(pick);
      setSearch('');
    } else if (visible.length === 0) toast(`No product found for "${s}"`, 'error');
  };

  const setLine = (productId: string, patch: Partial<CartLine>) => {
    if (patch.qty !== undefined) {
      const product = products.find((entry) => entry.id === productId);
      const currentQty = cart.find((line) => line.productId === productId)?.qty ?? 0;
      if (product && patch.qty > maxCartQuantity(product, currentQty)) {
        toast(`${product.name}: maximum available quantity is ${fmtQty(maxCartQuantity(product, currentQty))}`, 'error');
        return;
      }
    }
    setCart((c) => c.map((l) => (l.productId === productId ? { ...l, ...patch } : l)));
  };
  const removeLine = (productId: string) => setCart((c) => c.filter((l) => l.productId !== productId));

  useEffect(() => {
    if (lastAddedProductId) cartLineRefs.current.get(lastAddedProductId)?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, [cart, lastAddedProductId]);

  const selectGharMode = (ghar: boolean) => {
    if (gharOrderId || ghar === gharQuoteMode) return;
    if (ghar) {
      setGharQuoteMode(true);
      setHomeDelivery(false);
      setDiscount(0);
      setPaymentMode('cash');
      setGharAddress('');
      setGharQuoteError('');
      setSearch('');
      return;
    }
    setGharQuoteMode(false);
    setHomeDelivery(false);
    setDeliveryFee(0);
    setGharAddress('');
    setGharNote('');
    setGharQuoteError('');
    setCart((current) => current.map((line) => ({
      ...line,
      price: products.find((product) => product.id === line.productId)?.salePrice ?? line.price,
      discount: 0,
    })));
  };

  const reset = () => {
    setCart([]);
    setDiscount(0);
    setDeliveryFee(0);
    setGharOrderId(undefined);
    setGharQuoteMode(false);
    setHomeDelivery(false);
    setDeliveryAddress('');
    setBusinessPricing(false);
    setGharAddress('');
    setGharNote('');
    setGharQuoteError('');
    setGharQuotePending(false);
    setCustomerId(undefined);
    setPaymentMode('cash');
    setSearch('');
    searchRef.current?.focus();
  };

  useEffect(() => {
    const state = location.state as { gharOrder?: GharOrder; gharQuoteMode?: boolean } | null;
    const order = state?.gharOrder;
    if (state?.gharQuoteMode) {
      setCart([]);
      setCustomerId(undefined);
      setDiscount(0);
      setDeliveryFee(0);
      setGharOrderId(undefined);
      setGharQuoteMode(true);
      setHomeDelivery(false);
      setGharAddress('');
      setGharNote('Monthly ration');
      setPaymentMode('cash');
    } else if (order) {
      setCart(order.items.map((item) => ({ productId: item.productId, name: item.name, unit: item.unit, qty: item.qty, price: item.price, discount: 0 })));
      setDiscount(0);
      setCustomerId(order.customerId);
      setDeliveryFee(order.deliveryFee);
      setGharOrderId(order.id);
      setGharQuoteMode(false);
      setHomeDelivery(!!order.address.trim());
      setDeliveryAddress(order.address);
      setGharAddress(order.address);
      setGharNote(order.note ?? '');
      setPaymentMode('cash');
    } else return;
    navigate('/pos', { replace: true, state: null });
  }, [location.state, navigate]);

  useEffect(() => {
    if (!gharQuoteMode || gharOrderId || cart.length === 0) return;
    const request = ++gharQuoteRequest.current;
    setGharQuotePending(true);
    const applyPrices = (lines: Array<{ productId: string; price: number }>, fee: number) => {
      if (request !== gharQuoteRequest.current) return;
      setCart((current) => {
        let changed = false;
        const next = current.map((line) => {
          const quote = lines.find((entry) => entry.productId === line.productId);
          if (!quote || quote.price === line.price) return line;
          changed = true;
          return { ...line, price: quote.price, discount: 0 };
        });
        return changed ? next : current;
      });
      setDeliveryFee(homeDelivery ? fee : 0);
      setGharQuoteError('');
      setGharQuotePending(false);
    };

    const gharPricing = calculatePricing({
      lines: cart.filter((line) => line.qty > 0).map(({ productId, qty }) => ({ productId, qty })),
      products: products.map((product) => ({ id: product.id, salePrice: product.salePrice, thresholdPrice: product.thresholdPrice, wholesalePrice: product.wholesalePrice, categoryId: product.categoryId })),
      settings: {
        autoDiscountEnabled: settings?.autoDiscountEnabled ?? true,
        threshold: settings?.autoDiscountMinOrder ?? settings?.gharFreeDeliveryThreshold ?? 400000,
        defaultPercent: settings?.autoDiscountPct ?? settings?.gharDiscountPct ?? 5,
        maxPercent: settings?.autoDiscountMaxPct ?? 70,
        categoryRules: settings?.autoDiscountCategoryRules?.length
          ? settings.autoDiscountCategoryRules
          : settings?.autoDiscountCategoryId && settings.autoDiscountCategoryId !== 'all'
            ? [{ categoryId: settings.autoDiscountCategoryId, percent: settings.autoDiscountPct ?? 5, enabled: true }]
            : [],
        deliveryEnabled: settings?.homeDeliveryEnabled ?? true,
        deliveryCharge: settings?.deliveryCharge ?? settings?.gharDeliveryFee ?? 15000,
        freeDeliveryThreshold: settings?.freeDeliveryThreshold ?? settings?.gharFreeDeliveryThreshold ?? 400000,
        businessPricingEnabled: settings?.businessPricingEnabled ?? true,
      },
      homeDelivery,
    });
    const minimumMarginPct = Math.min(99, Math.max(0, settings?.gharMinimumMarginPct ?? 10));
    const lines = cart.map((line) => {
      const product = products.find((entry) => entry.id === line.productId);
      if (!product) return { productId: line.productId, price: line.price };
      const calculated = gharPricing.lines.find((entry) => entry.productId === product.id);
      const discountedPrice = calculated ? product.salePrice - calculated.discount / line.qty : product.salePrice;
      const floor = product.cost > 0 ? Math.ceil((product.cost * 100) / (100 - minimumMarginPct)) : 0;
      return { productId: product.id, price: Math.min(product.salePrice, Math.max(Math.round(discountedPrice), floor)) };
    });
    const subtotal = cart.reduce((sum, line) => {
      const price = lines.find((entry) => entry.productId === line.productId)?.price ?? line.price;
      return sum + Math.round(price * line.qty);
    }, 0);
    const fee = gharPricing.deliveryCharge;
    applyPrices(lines, fee);
  }, [cart, gharQuoteMode, gharOrderId, homeDelivery, products, settings]);

  const holdCart = async () => {
    if (cart.length === 0) return;
    await db.heldCarts.add({ id: uid(), label: `Bill ${held.length + 1} · ${rs(total)}`, date: nowIso(), customerId, items: cart.map((l) => ({ ...l, cost: 0, returnedQty: 0 })), discount });
    toast('Bill put on hold');
    reset();
  };

  const maxDiscountOk = () => {
    if (user.role !== 'cashier' || subtotal === 0) return true;
    const manualDiscountLimitBase = Math.max(0, subtotal - lineDiscountTotal);
    return manualDiscountLimitBase === 0
      ? discount === 0
      : (discount / manualDiscountLimitBase) * 100 <= (settings?.cashierMaxDiscount ?? 5) + 0.001;
  };

  const startPay = () => {
    if (gharQuoteMode) return;
    if (cart.length === 0) return;
    if (total < 0) return toast('Discount is more than the bill', 'error');
    if (!maxDiscountOk()) return toast(`Cashier discount limit is ${settings?.cashierMaxDiscount}% — ask the manager`, 'error');
    if (paymentMode === 'credit' && !customerId) return toast('Udhaar ke liye customer select karein', 'error');
    if (homeDelivery && (!customerId || !deliveryAddress.trim())) return toast('Home delivery requires a selected customer and delivery address', 'error');
    if (businessPricing && !settings?.businessPricingEnabled) return toast('Shopkeeper pricing is disabled in Settings', 'error');
    searchRef.current?.blur();
    setPaying(true);
  };

  const saveGharInvoice = () => run(async () => {
    if (!customerId) throw new Error('Select a customer for the monthly ration invoice');
    if (homeDelivery && !gharAddress.trim()) throw new Error('Enter the home delivery address');
    const items = cart.filter((line) => line.qty > 0);
    if (items.length === 0) throw new Error('Add at least one product');
    const id = uid();
    const date = nowIso();
    {
      const customer = await db.customers.get(customerId);
      if (!customer) throw new Error('Customer not found');
      const order: GharOrder = {
        id,
        no: `GH-${date.slice(2, 7).replace('-', '')}-${id.slice(0, 5).toUpperCase()}`,
        date,
        customerId,
        customerName: customer.name,
        phone: customer.phone,
        address: homeDelivery ? gharAddress.trim() : '',
        items: items.map((line) => {
          const product = products.find((entry) => entry.id === line.productId);
          return {
            productId: line.productId,
            name: line.name,
            unit: line.unit,
            qty: line.qty,
            price: line.price,
            regularPrice: product?.salePrice ?? line.price,
            cost: product?.cost ?? 0,
          };
        }),
        subtotal,
        deliveryFee,
        total,
        status: 'invoice_draft',
        ...(gharNote.trim() ? { note: gharNote.trim() } : {}),
        userId: user.id,
      };
      await db.gharOrders.add(order);
    }
    navigate('/pos');
  }, 'Monthly ration invoice saved');

  useEffect(() => searchRef.current?.focus(), []);

  // Voice billing fills this same bill through the same functions as tapping and typing.
  const voice = useVoiceAssistant({
    cartQty: (id) => cart.find((l) => l.productId === id)?.qty ?? 0,
    customerId,
    addToBill: addProduct,
    setCustomer: setCustomerId,
    setPayment: (mode) => {
      if (mode === 'credit') setRemovedCreditDiscount(pricing?.discountAmount ?? 0);
      else setRemovedCreditDiscount(0);
      setPaymentMode(mode);
    },
    searchProduct: (text) => {
      setSearch(text);
      searchRef.current?.focus();
    },
    userId: user.id,
    canKhataAmount: has('customers.manage'),
  });

  // Keep existing F2/F9 behavior and add POS-specific shortcuts without intercepting text entry.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (document.querySelector('[data-modal]')) return;
      if (e.key === 'F1') {
        e.preventDefault();
        searchRef.current?.focus();
      }
      if (e.key === 'F2' && !gharOrderId) {
        e.preventDefault();
        setCustomerFocusRequest((request) => request + 1);
      }
      if (e.key === 'F3' && cart.length > 0 && !gharQuoteMode) {
        e.preventDefault();
        void holdCart();
      }
      if (e.key === 'F4' && held.length > 0 && !gharQuoteMode) {
        e.preventDefault();
        setShowHeld(true);
      }
      if (e.key === 'F5' && !gharOrderId && settings?.homeDeliveryEnabled !== false) {
        e.preventDefault();
        setHomeDelivery((enabled) => !enabled);
      }
      if (e.key === 'F6' && !gharOrderId && settings?.businessPricingEnabled !== false) {
        e.preventDefault();
        if (businessPricing) setBusinessPricing(false);
        else setConfirmBusinessPricing(true);
      }
      if ((e.key === 'F7' || e.key === 'F9' || e.key === 'F10') && !paying) {
        e.preventDefault();
        startPay();
      }
      const activeElement = document.activeElement as HTMLElement | null;
      const editingText = !!activeElement && (activeElement.tagName === 'INPUT' || activeElement.tagName === 'TEXTAREA' || activeElement.tagName === 'SELECT' || activeElement.isContentEditable);
      if (e.key === 'Delete' && !editingText && selectedProductId && !gharOrderId) {
        e.preventDefault();
        removeLine(selectedProductId);
        setSelectedProductId(null);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  return (
    <div className="-m-4 flex min-h-full flex-col bg-slate-100 p-3 pb-24 sm:p-4 lg:-m-6 lg:h-[calc(100vh-49px)] lg:flex-row lg:gap-4 lg:overflow-hidden lg:p-4 lg:pb-4">
      <section className="flex min-h-[50vh] min-w-0 flex-1 flex-col lg:min-h-0">
        <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
          <Button
            variant={gharQuoteMode ? 'secondary' : 'ghost'}
            disabled={!!gharOrderId || !can('ration')}
            aria-pressed={gharQuoteMode || !!gharOrderId}
            onClick={() => selectGharMode(!gharQuoteMode)}
          >
            <Home size={16} /> {gharQuoteMode ? 'Return to regular sale' : 'Make this a ration order'}
          </Button>
          <span className="hidden text-xs text-slate-500 sm:inline">Live stock</span>
        </div>
        <div className="relative mb-3 rounded-lg border border-slate-200 bg-white p-2 shadow-sm">
          <Search size={18} className="absolute top-1/2 left-5 -translate-y-1/2 text-teal-700" />
          <Input
            ref={searchRef}
            className="border-0 py-3 pl-10 text-base shadow-none focus:ring-0"
            placeholder="Scan barcode or search product…  F1"
            value={search}
            disabled={!!gharOrderId}
            onChange={(e) => setSearch(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && onSearchEnter()}
          />
        </div>
        <div className="mb-3 flex gap-1.5 overflow-x-auto pb-1">
          {[{ id: 'fav', name: '★ Favourites' }, { id: 'all', name: 'Top sellers' }, ...categories].map((c) => (
            <button
              key={c.id}
              disabled={!!gharOrderId}
              onClick={() => {
                setCategory(c.id);
                setSearch('');
              }}
              className={cx(
                'shrink-0 rounded-md border px-3 py-1.5 text-sm font-medium transition-colors',
                category === c.id && !search ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-200 bg-white text-slate-600 hover:border-slate-400 hover:text-slate-900',
              )}
            >
              {c.name}
            </button>
          ))}
        </div>
        <div className="grid min-h-0 flex-1 auto-rows-min grid-cols-2 gap-2 overflow-y-auto pr-1 sm:grid-cols-3 xl:grid-cols-4">
          {visible.map((p) => (
            <button
              key={p.id}
              onClick={() => addProduct(p)}
              disabled={!!gharOrderId}
              className="group flex min-h-28 flex-col rounded-md border border-slate-200 bg-white p-3 text-left transition hover:border-teal-600 hover:shadow-md disabled:cursor-not-allowed disabled:opacity-60"
            >
              <div className="flex items-start justify-between gap-1">
                <span className="line-clamp-2 text-sm font-semibold text-slate-800 group-hover:text-teal-800">{p.name}</span>
                {p.favorite && <Star size={14} className="shrink-0 fill-amber-400 text-amber-500" />}
              </div>
              {p.nameUr && <span className="urdu text-xs text-slate-500">{p.nameUr}</span>}
              <div className="mt-auto flex items-end justify-between gap-2 pt-3">
                <span className="font-bold tabular-nums text-slate-900">{rs(p.salePrice)}</span>
                <span className={cx('text-xs', stockVisibleToThisCart(p) <= 0 ? 'text-rose-600' : stockVisibleToThisCart(p) <= p.minStock ? 'text-amber-600' : 'text-slate-400')}>
                  {fmtQty(stockVisibleToThisCart(p))} {p.unit}
                </span>
              </div>
            </button>
          ))}
          {visible.length === 0 && (
            <div className="col-span-full">
              <Empty icon={<Search size={36} />} title="No products found">
                {can('products') ? 'Add products from the Products page.' : 'Ask the owner to add this product.'}
              </Empty>
            </div>
          )}
        </div>
      </section>

      {/* Cart */}
      <section className="flex min-h-0 w-full flex-col overflow-hidden rounded-lg border border-slate-300 bg-white shadow-lg lg:min-h-0 lg:w-[410px] lg:shrink-0">
        <div className="flex items-center justify-between border-b border-slate-200 bg-slate-950 px-4 py-3 text-white">
          <h2 className="flex items-center gap-2 font-semibold">
            <ShoppingCart size={18} className="text-teal-300" /> Current bill <span className="rounded bg-white/10 px-1.5 py-0.5 text-xs font-normal text-slate-300">{cart.length}</span>
          </h2>
          <div className="flex gap-1">
            {!gharOrderId && !gharQuoteMode && held.length > 0 && (
              <Button size="sm" variant="secondary" onClick={() => setShowHeld(true)}>
                Held ({held.length})
              </Button>
            )}
            {!gharOrderId && !gharQuoteMode && <Button size="sm" variant="ghost" onClick={holdCart} disabled={cart.length === 0} title="Hold bill">
              <PauseCircle size={16} /> Hold
            </Button>}
            <Button size="sm" variant="ghost" className="text-slate-300 hover:text-white hover:bg-white/10" onClick={reset} disabled={cart.length === 0} title="Clear">
              <Trash2 size={16} />
            </Button>
          </div>
        </div>
        <div className="border-b border-slate-100 bg-slate-50/70 p-3">
          {gharOrderId ? (
            <div className="rounded-lg border border-brand-200 bg-brand-50 px-3 py-2 text-sm">
              <div className="font-medium">Ghar se ghar tak · {billCustomer?.name ?? 'Customer'}</div>
              <div className="text-xs text-slate-600">Confirmed delivery order · customer and quoted rates are locked</div>
            </div>
          ) : <CustomerPicker value={customerId} onChange={(id) => {
            setCustomerId(id);
          }} focusRequest={customerFocusRequest} />}
          {!gharOrderId && <div className="mt-3 flex flex-wrap gap-1.5">
            <Button size="sm" className="rounded-md" variant={homeDelivery ? 'secondary' : 'ghost'} aria-pressed={homeDelivery} disabled={settings?.homeDeliveryEnabled === false} onClick={() => setHomeDelivery(!homeDelivery)}>
              <Truck size={15} /> {homeDelivery ? 'Home delivery on' : 'Home delivery off'}
            </Button>
            {!gharQuoteMode && <Button size="sm" className="rounded-md" variant={businessPricing ? 'secondary' : 'ghost'} aria-pressed={businessPricing} disabled={settings?.businessPricingEnabled === false} onClick={() => businessPricing ? setBusinessPricing(false) : setConfirmBusinessPricing(true)}>
              Shopkeeper rate {businessPricing ? 'on' : 'off'}
            </Button>}
            <Button size="sm" variant="ghost" title="Keyboard shortcuts" aria-label="Keyboard shortcuts" onClick={() => setShowShortcuts(true)}><Keyboard size={15} /></Button>
          </div>}
          {homeDelivery && !gharOrderId && <div className="mt-3">
            <Field label="Delivery address">
              <Input value={gharQuoteMode ? gharAddress : deliveryAddress} onChange={(event) => gharQuoteMode ? setGharAddress(event.target.value) : setDeliveryAddress(event.target.value)} placeholder="Required for home delivery" />
            </Field>
          </div>}
          {gharQuoteMode && <div className="mt-3 grid gap-2 sm:grid-cols-2">
            <Field label="Invoice note"><Input value={gharNote} onChange={(event) => setGharNote(event.target.value)} placeholder="Monthly ration" /></Field>
          </div>}
          {gharQuoteMode && gharQuoteError && <div role="alert" className="mt-2 text-sm text-rose-700">{gharQuoteError}</div>}
        </div>
        {!gharOrderId && voice.panel}
        <div className="max-h-[34vh] overflow-y-auto lg:min-h-0 lg:max-h-none lg:flex-1">
          {cart.length === 0 ? (
            <Empty icon={<ShoppingCart size={36} />} title="Bill is empty">
              Tap a product or scan a barcode.
            </Empty>
          ) : (
            <ul className="divide-y divide-slate-100">
              {cart.map((l) => {
                const calculated = pricing?.lines.find((line) => line.productId === l.productId);
                const displayPrice = calculated?.price ?? l.price;
                const displayDiscount = calculated?.discount ?? l.discount;
                return <li ref={(node) => { if (node) cartLineRefs.current.set(l.productId, node); else cartLineRefs.current.delete(l.productId); }} key={l.productId} tabIndex={0} onFocus={() => setSelectedProductId(l.productId)} onClick={() => setSelectedProductId(l.productId)} className={cx('px-3 py-2 outline-none focus:bg-sky-50', selectedProductId === l.productId && 'bg-slate-50')}>
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 text-sm font-medium">{l.name}</div>
                    <div className="text-right text-sm font-semibold tabular-nums">
                      {rs(lineTotal(displayPrice, l.qty) - displayDiscount)}
                      {displayDiscount > 0 && <div className="text-xs font-normal text-emerald-700">-{rs(displayDiscount)} · {calculated?.discountPercent.toFixed(1)}%</div>}
                      {calculated?.rule === 'business' && <div className="text-xs font-normal text-sky-700">Shopkeeper rate</div>}
                    </div>
                  </div>
                  <div className="mt-1 flex items-center gap-2">
                    <button disabled={!!gharOrderId} className="rounded border border-slate-300 p-1 hover:bg-slate-50 disabled:opacity-40" onClick={() => (l.qty > 1 ? setLine(l.productId, { qty: roundQty(l.qty - 1) }) : removeLine(l.productId))}>
                      <Minus size={14} />
                    </button>
                    <input
                      className="w-16 rounded border border-slate-300 px-1 py-0.5 text-center text-sm"
                      inputMode="decimal"
                      value={l.qty}
                      readOnly={!!gharOrderId}
                      onChange={(e) => {
                        const v = Number(e.target.value);
                        if (Number.isFinite(v) && v >= 0) setLine(l.productId, { qty: roundQty(v) });
                      }}
                    />
                    <button disabled={!!gharOrderId} className="rounded border border-slate-300 p-1 hover:bg-slate-50 disabled:opacity-40" onClick={() => setLine(l.productId, { qty: roundQty(l.qty + 1) })}>
                      <Plus size={14} />
                    </button>
                    <span className="text-xs text-slate-500">
                      {l.unit} ×{' '}
                      {has('sales.price_override') && !gharOrderId && !gharQuoteMode ? (
                        <input
                          className="w-20 rounded border border-slate-200 px-1 py-0.5 text-right text-xs"
                          inputMode="decimal"
                          defaultValue={l.price / 100}
                          onBlur={(e) => {
                            const v = Math.round(Number(e.target.value) * 100);
                            if (Number.isFinite(v) && v >= 0) setLine(l.productId, { price: v });
                          }}
                          title="Change price"
                        />
                      ) : (
                        rs(displayPrice)
                      )}
                    </span>
                    <button disabled={!!gharOrderId} className="ml-auto rounded p-1 text-slate-400 hover:bg-rose-50 hover:text-rose-600 disabled:opacity-40" onClick={() => removeLine(l.productId)} aria-label="Remove">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </li>;
              })}
            </ul>
          )}
        </div>
        <div className="space-y-2 border-t border-slate-200 bg-white p-3 sm:p-4">
          <div className="flex justify-between text-sm text-slate-500"><span>Subtotal</span><span className="tabular-nums text-slate-800">{rs(subtotal)}</span></div>
          {lineDiscountTotal > 0 && <div className="flex justify-between text-sm text-emerald-700"><span>Auto discount · {pricing?.discountPercent.toFixed(1)}%</span><span className="tabular-nums">−{rs(lineDiscountTotal)}</span></div>}
          {paymentMode === 'credit' && removedCreditDiscount > 0 && <div className="flex justify-between text-sm text-amber-700"><span>Discount removed for Udhaar</span><span className="tabular-nums">+{rs(removedCreditDiscount)}</span></div>}
          <div className="flex items-center justify-between gap-3 text-sm">
            <span className="flex items-center gap-2 text-slate-500">
              Manual discount
              <MoneyInput className="w-24 py-1 text-right" value={discount} disabled={!!gharOrderId || gharQuoteMode} onChange={setDiscount} />
            </span>
            {activeDeliveryFee > 0 && <span className="text-slate-600">Delivery {rs(activeDeliveryFee)}</span>}
          </div>
          {(homeDelivery || gharOrderId || gharQuoteMode) && <div className="flex justify-between text-sm text-slate-600"><span>{homeDelivery ? 'Home delivery' : 'Collection'}</span><span>{homeDelivery ? (activeDeliveryFee ? rs(activeDeliveryFee) : 'Free') : 'No delivery'}</span></div>}
          <div className="mt-1 flex items-end justify-between border-t border-slate-200 pt-2">
            <span className="text-sm font-semibold text-slate-600">{paymentMode === 'credit' ? 'Total Udhaar' : 'Payable'}</span>
            <span className="text-2xl font-bold tabular-nums text-slate-950">{rs(total)}</span>
          </div>
          {!gharQuoteMode && <div className="grid grid-cols-2 gap-2">
            {(['cash', 'credit'] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => {
                  if (m === 'credit') {
                    setRemovedCreditDiscount(pricing?.discountAmount ?? 0);
                  } else {
                    setRemovedCreditDiscount(0);
                    setPaying(false);
                  }
                  setPaymentMode(m);
                }}
                className={cx(
                  'rounded-md border py-2 text-sm font-semibold',
                  paymentMode === m
                    ? m === 'credit'
                      ? 'border-rose-600 bg-rose-600 text-white'
                      : 'border-emerald-600 bg-emerald-600 text-white'
                    : 'border-slate-300 bg-white text-slate-600 hover:bg-slate-50',
                )}
              >
                {m === 'cash' ? 'Cash' : 'Udhaar'}
              </button>
            ))}
          </div>}
          {!gharQuoteMode && paymentMode === 'credit' && (
            <div className="rounded-lg border border-rose-200 bg-rose-50 px-3 py-2 text-sm">
              <div>
                Customer: <b>{billCustomer?.name ?? '— select above —'}</b>
              </div>
              <div>
                Total: <b>{rs(total)}</b> · Payment: <b className="text-rose-700">UDHAAR</b>
              </div>
            </div>
          )}
          {businessPricing && <div className="rounded border border-sky-200 bg-sky-50 px-3 py-2 text-sm text-sky-900">Shopkeeper/business pricing active. Automatic threshold discounts are not stacked.</div>}
          {homeDelivery && <div className="rounded border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">Delivery: {activeDeliveryFee ? rs(activeDeliveryFee) : 'Free'}{(gharQuoteMode ? gharAddress : deliveryAddress).trim() ? ` · ${(gharQuoteMode ? gharAddress : deliveryAddress).trim()}` : ' · address required'}</div>}
          {paymentMode === 'credit' && removedCreditDiscount > 0 && <div className="rounded border border-amber-200 bg-amber-50 px-3 py-2 text-sm text-amber-900">Udhaar removed the automatic discount of {rs(removedCreditDiscount)}. The full remaining bill is recorded on the customer account.</div>}
          {!gharOrderId && !gharQuoteMode && voice.button}
          {gharQuoteMode ? (
            <Button size="lg" className="w-full" disabled={cart.length === 0 || !customerId || (homeDelivery && !gharAddress.trim()) || !!gharQuoteError || gharQuotePending} onClick={() => void saveGharInvoice()}>
              <ShoppingCart size={17} /> {gharQuotePending ? 'Checking Ghar prices…' : `Save monthly invoice · ${rs(total)}`}
            </Button>
          ) : <Button size="lg" variant={paymentMode === 'credit' ? 'danger' : 'success'} className="w-full rounded-md py-3" disabled={cart.length === 0} onClick={startPay}>
            {paymentMode === 'credit' ? `Save udhaar bill — ${rs(total)} (F9)` : `Pay ${rs(total)} (F9)`}
          </Button>}
        </div>
      </section>

      {paying && (
        <PayModal
          total={total}
          customerId={customerId}
          startOnCredit={paymentMode === 'credit'}
          allowCredit={paymentMode === 'credit'}
          onSwitchToCash={() => {
            setRemovedCreditDiscount(0);
            setPaying(false);
            setPaymentMode('cash');
          }}
          onSwitchToCredit={() => {
            setRemovedCreditDiscount((current) => current || pricing?.discountAmount || 0);
            setPaymentMode('credit');
            if (!customerId) {
              setPaying(false);
              toast('Select a customer, then continue with Udhaar', 'error');
            }
          }}
          onClose={() => setPaying(false)}
          onPaid={async (payments, note) => {
            // Only what was chosen is sent; the server takes prices, discounts, cost and stock from its own records.
            const sale = await completeSale({
              items: cart.filter((line) => line.qty > 0).map(({ productId, name, unit, qty, price, discount: lineDiscount }) => ({ productId, name, unit, qty, price, discount: lineDiscount })),
              discount,
              deliveryFee: activeDeliveryFee,
              ...(homeDelivery ? { deliveryAddress: gharQuoteMode ? gharAddress.trim() : deliveryAddress.trim() } : {}),
              pricingMode: businessPricing ? 'business' : 'normal',
              paymentMethod: paymentMode,
              homeDelivery,
              ...(gharOrderId ? { gharOrderId } : {}),
              ...(customerId ? { customerId } : {}),
              payments,
              ...(note ? { note } : {}),
            });
            setPaying(false);
            setReceipt(sale);
            reset();
          }}
        />
      )}
      {receipt && <ReceiptModal sale={receipt} autoPrint onClose={() => { setReceipt(null); searchRef.current?.focus(); }} />}
      {confirmBusinessPricing && <Modal
        title="Apply Shopkeeper/Business Rate?"
        onClose={() => setConfirmBusinessPricing(false)}
        footer={<>
          <Button variant="secondary" onClick={() => setConfirmBusinessPricing(false)}>Cancel</Button>
          <Button onClick={() => { setBusinessPricing(true); setConfirmBusinessPricing(false); }}>Apply rate</Button>
        </>}
      >
        <p className="text-sm text-slate-600">This bill will use each product's wholesale price when available. The normal threshold discount will not be added.</p>
      </Modal>}
      {showShortcuts && <Modal title="POS keyboard shortcuts" onClose={() => setShowShortcuts(false)}>
        <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
          <span>F1</span><span>Focus product search</span>
          <span>F2</span><span>Select/change customer</span>
          <span>F3</span><span>Hold bill</span>
          <span>F4</span><span>Recall held bill</span>
          <span>F5</span><span>Toggle home delivery</span>
          <span>F6</span><span>Shopkeeper rate (confirmation)</span>
          <span>F7 / F9 / F10</span><span>Open payment</span>
          <span>F8 / hold Space</span><span>Voice input</span>
          <span>Delete</span><span>Remove selected cart item (outside inputs)</span>
          <span>Esc</span><span>Close the current dialog</span>
        </div>
      </Modal>}
      {!gharOrderId && voice.floatingButton}
      {showHeld && !gharQuoteMode && (
        <Modal title="Held bills" onClose={() => setShowHeld(false)}>
          <ul className="divide-y divide-slate-100">
            {held.map((h) => (
              <li key={h.id} className="flex items-center justify-between py-2">
                <span className="text-sm">{h.label}</span>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    onClick={async () => {
                      if (cart.length > 0) await holdCart();
                      setCart(h.items.map(({ cost: _c, returnedQty: _r, ...l }) => l));
                      setDiscount(h.discount);
                      setCustomerId(h.customerId);
                      await db.heldCarts.delete(h.id);
                      setShowHeld(false);
                    }}
                  >
                    Resume
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => db.heldCarts.delete(h.id)}>
                    <Trash2 size={14} />
                  </Button>
                </div>
              </li>
            ))}
          </ul>
        </Modal>
      )}
    </div>
  );
}

/** Payment: cash with change, wallets/bank, split payment, remainder on udhaar. */
function PayModal({
  total,
  customerId,
  startOnCredit,
  allowCredit,
  onSwitchToCash,
  onSwitchToCredit,
  onClose,
  onPaid,
}: {
  total: number;
  customerId?: string;
  /** Udhaar bill: start with no cash received, so the full amount goes on the khata. */
  startOnCredit?: boolean;
  allowCredit: boolean;
  onSwitchToCash: () => void;
  onSwitchToCredit: () => void;
  onClose: () => void;
  onPaid: (payments: { accountId: string; amount: number }[], note?: string) => Promise<void>;
}) {
  const accounts = useLiveQuery(() => db.accounts.filter((a) => a.active).toArray(), []) ?? [];
  const balances = useLiveQuery(() => partyBalances('customer'), []) ?? new Map<string, number>();
  const customer = useLiveQuery(() => (customerId ? db.customers.get(customerId) : undefined), [customerId]);
  const [amounts, setAmounts] = useState<Record<string, number>>({ [ACCOUNT_IDS.cash]: startOnCredit ? 0 : total });
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const run = useAction();

  const paid = Object.values(amounts).reduce((s, v) => s + (v || 0), 0);
  const change = Math.max(0, paid - total);
  const credit = Math.max(0, total - paid);
  const newBalance = (customerId ? balances.get(customerId) ?? 0 : 0) + credit;
  const overLimit = customer && customer.creditLimit > 0 && credit > 0 && newBalance > customer.creditLimit;

  const set = (id: string, v: number) => setAmounts((a) => ({ ...a, [id]: v }));
  const quick = [total, ...[50000, 100000, 500000].filter((v) => v > total)].slice(0, 4);

  const submit = () =>
    run(async () => {
      if (credit > 0 && !allowCredit) throw new OpError(`Rs. ${rs(credit)} remains unpaid. Switch to Udhaar to put it on a customer account.`);
      if (credit > 0 && !customerId) throw new OpError('Select a customer to put the remaining amount on udhaar');
      setBusy(true);
      try {
        await onPaid(
          Object.entries(amounts).map(([accountId, amount]) => ({ accountId, amount })),
          note || undefined,
        );
      } finally {
        setBusy(false);
      }
    });

  return (
    <Modal
      title={`Payment — ${rs(total)}`}
      onClose={onClose}
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Back
          </Button>
          {allowCredit && <Button variant="secondary" onClick={onSwitchToCash}>Switch to Cash</Button>}
          {credit > 0 && !allowCredit ? <Button variant="danger" size="lg" disabled={busy} onClick={onSwitchToCredit}>Switch to Udhaar — {rs(credit)} unpaid</Button>
            : <Button variant="success" size="lg" disabled={busy} onClick={submit}>{credit > 0 ? `Complete — ${rs(credit)} on udhaar` : 'Complete cash sale'}</Button>}
        </>
      }
    >
      <div className="grid gap-4">
        <Field label="Cash received">
          <MoneyInput
            className="py-3 text-lg"
            value={amounts[ACCOUNT_IDS.cash] ?? 0}
            onChange={(v) => set(ACCOUNT_IDS.cash, v)}
            onKeyDown={(e) => e.key === 'Enter' && submit()}
            autoFocus
            onFocus={(e) => e.currentTarget.select()}
          />
        </Field>
        <div className="flex flex-wrap gap-2">
          {quick.map((v) => (
            <Button key={v} size="sm" variant="secondary" onClick={() => set(ACCOUNT_IDS.cash, v)}>
              {v === total ? 'Exact' : rs(v)}
            </Button>
          ))}
          <Button size="sm" variant="secondary" onClick={() => set(ACCOUNT_IDS.cash, 0)}>
            No cash
          </Button>
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          {accounts
            .filter((a) => a.id !== ACCOUNT_IDS.cash)
            .map((a) => (
              <Field key={a.id} label={a.name}>
                <MoneyInput value={amounts[a.id] ?? 0} onChange={(v) => set(a.id, v)} />
              </Field>
            ))}
        </div>
        <div className="rounded-lg bg-slate-50 p-3 text-sm">
          <div className="flex justify-between">
            <span>Paid</span>
            <span className="font-medium">{rs(paid)}</span>
          </div>
          {change > 0 && (
            <div className="flex justify-between text-lg font-bold text-emerald-700">
              <span>Change to give</span>
              <span>{rs(change)}</span>
            </div>
          )}
          {credit > 0 && (
            <div className="flex justify-between font-semibold text-rose-600">
              <span>Udhaar (goes to khata)</span>
              <span>{rs(credit)}</span>
            </div>
          )}
          {credit > 0 && !customerId && <p className="mt-1 text-rose-600">Select a customer on the bill for udhaar.</p>}
          {overLimit && (
            <p className="mt-1">
              <Badge tone="amber">Over credit limit</Badge> New balance {rs(newBalance)} / limit {rs(customer!.creditLimit)}
            </p>
          )}
        </div>
        <Field label="Note (optional)">
          <Input value={note} onChange={(e) => setNote(e.target.value)} />
        </Field>
      </div>
    </Modal>
  );
}
