const { app, BrowserWindow, shell } = require('electron');
const { spawn } = require('node:child_process');
const { generateKeyPairSync, randomBytes } = require('node:crypto');
const path = require('node:path');
const fs = require('node:fs');

let mainWindow;
let apiProcess;

function makeAppDirs() {
  const appDataRoot = path.join(app.getPath('appData'), 'KaryanaShop');
  const dirs = [
    appDataRoot,
    path.join(appDataRoot, 'data'),
    path.join(appDataRoot, 'backups'),
    path.join(appDataRoot, 'logs'),
    path.join(appDataRoot, 'config'),
  ];

  for (const dir of dirs) {
    fs.mkdirSync(dir, { recursive: true });
  }

  return { appDataRoot, dataDir: path.join(appDataRoot, 'data') };
}

function startBackend() {
  const { appDataRoot, dataDir } = makeAppDirs();
  const apiRoot = path.resolve(__dirname, '../api');
  const builtEntry = path.join(apiRoot, 'dist', 'server.js');
  const sourceEntry = path.join(apiRoot, 'src', 'server.ts');
  const keysDir = path.join(appDataRoot, 'keys');
  fs.mkdirSync(keysDir, { recursive: true });

  const jwtFile = path.join(keysDir, 'jwt-ed25519.pem');
  if (!fs.existsSync(jwtFile)) {
    const { privateKey } = generateKeyPairSync('ed25519');
    const pem = privateKey.export({ type: 'pkcs8', format: 'pem' }).toString();
    fs.writeFileSync(jwtFile, pem, { mode: 0o600 });
  }

  const encryptionFile = path.join(keysDir, 'app-encryption.key');
  if (!fs.existsSync(encryptionFile)) {
    fs.writeFileSync(encryptionFile, randomBytes(32).toString('base64'), { mode: 0o600 });
  }

  const env = {
    ...process.env,
    NODE_ENV: 'production',
    HOST: '127.0.0.1',
    PORT: '4000',
    KEYS_DIR: keysDir,
    DATABASE_URL: process.env.DATABASE_URL || `mysql://retailos_app:CHANGE_ME@127.0.0.1:3307/retailos`,
    CORS_ORIGINS: 'http://127.0.0.1:5173,http://localhost:5173',
    JWT_PRIVATE_KEY: fs.readFileSync(jwtFile, 'utf8').replace(/\r/g, ''),
    APP_ENCRYPTION_KEY: fs.readFileSync(encryptionFile, 'utf8').trim(),
    APPDATA_DIR: appDataRoot,
    DATA_DIR: dataDir,
  };

  const spawnOptions = {
    cwd: apiRoot,
    env,
    stdio: 'inherit',
    windowsHide: true,
  };

  if (fs.existsSync(builtEntry)) {
    apiProcess = spawn(process.execPath, [builtEntry], spawnOptions);
    apiProcess.on('exit', (code, signal) => {
      if (code !== null && code !== 0) {
        console.error(`API exited with code ${code} signal ${signal}`);
      }
    });
    return;
  }

  if (fs.existsSync(sourceEntry)) {
    const tsxCommand = process.platform === 'win32' ? 'npx.cmd' : 'npx';
    apiProcess = spawn(tsxCommand, ['tsx', 'src/server.ts'], spawnOptions);
    apiProcess.on('exit', (code, signal) => {
      if (code !== null && code !== 0) {
        console.error(`API exited with code ${code} signal ${signal}`);
      }
    });
    return;
  }

  console.error('No API entrypoint found. Expected either:', builtEntry, 'or', sourceEntry);
}

function createWindow() {
  const appRoot = path.resolve(__dirname, '../web/dist');
  const indexFile = path.join(appRoot, 'index.html');

  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1100,
    minHeight: 700,
    backgroundColor: '#0f172a',
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      webSecurity: false,
    },
    icon: path.join(__dirname, 'icon.ico'),
  });

  mainWindow.once('ready-to-show', () => mainWindow.show());

  mainWindow.webContents.on('did-fail-load', (_event, code, description) => {
    console.error('Failed to load app:', code, description);
    console.error('Index file attempted:', indexFile);
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.loadFile(indexFile);
}

app.whenReady().then(() => {
  startBackend();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('before-quit', () => {
  if (apiProcess && !apiProcess.killed) {
    apiProcess.kill('SIGTERM');
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});
