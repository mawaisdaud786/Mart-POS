import { ALL_PERMISSIONS, SYSTEM_ROLES, type AccountTxn, type Permission, type Product, type Sale } from '@retailos/domain';
import { beforeEach, describe, expect, it } from 'vitest';
import * as ops from '../src/modules/shop/ops';
import { MemoryStore } from './memory-store';

// One counter for every caller, like random UUIDs in production: ids must never collide.
let idCounter = 0;
const ctxFor = (permissions: readonly Permission[], userId = 'u-test'): ops.OpContext => {
  const set = new Set(permissions);
  return { userId, can: (p) => set.has(p), newId: () => `id-${++idCounter}`, now: () => '2026-10-04T10:00:00.000Z' };
};
const owner = () => ctxFor(ALL_PERMISSIONS, 'u-owner');
const cashier = () => ctxFor(SYSTEM_ROLES.cashier.permissions, 'u-cashier');
const manager = () => ctxFor(SYSTEM_ROLES.manager.permissions, 'u-manager');

const product = (id: string, over: Partial<Product> = {}): Product => ({
  id, name: `Product ${id}`, sku: id, unit: 'Packet', salePrice: 10_000, cost: 8_000, stock: 100, minStock: 5, favorite: false, active: true, createdAt: '2026-01-01T00:00:00.000Z', ...over,
});

let s: MemoryStore;
beforeEach(async () => {
  s = new MemoryStore();
  await ops.setupShop(s, owner(), { shopName: 'Test Mart', address: '', phone: '', openingCash: 100_000 });
  await s.put('products', product('p1'));
  await s.put('products', product('p2', { salePrice: 5_000, cost: 4_000 }));
  await s.put('customers', { id: 'c1', name: 'Ali', creditLimit: 0, createdAt: '2026-01-01T00:00:00.000Z' });
  await s.put('suppliers', { id: 's1', name: 'Peak', createdAt: '2026-01-01T00:00:00.000Z' });
});

const cashBalance = () => ops.accountBalance(s, 'acc-cash');
const stockOf = async (id: string) => (await s.get<Product>('products', id))!.stock;
const sale = (over: Partial<ops.SaleInput> = {}): ops.SaleInput => ({
  items: [{ productId: 'p1', qty: 2, price: 10_000, discount: 0 }],
  discount: 0,
  payments: [{ accountId: 'acc-cash', amount: 20_000 }],
  ...over,
});

describe('first-run setup', () => {
  it('creates accounts, categories, counters and opening cash, once, for people who may', async () => {
    expect((await s.list('accounts')).map((a) => a.id).sort()).toEqual(['acc-bank', 'acc-cash', 'acc-easypaisa', 'acc-jazzcash']);
    expect((await s.list('categories')).length).toBeGreaterThan(5);
    expect(await cashBalance()).toBe(100_000);
    await expect(ops.setupShop(s, owner(), { shopName: 'Again', address: '', phone: '', openingCash: 0 })).rejects.toThrow(/already set up/);
    const fresh = new MemoryStore();
    await expect(ops.setupShop(fresh, cashier(), { shopName: 'X', address: '', phone: '', openingCash: 0 })).rejects.toMatchObject({ status: 403 });
  });
});

describe('completeSale', () => {
  it('takes stock, money and numbers from the database and writes every effect', async () => {
    const r = await ops.completeSale(s, cashier(), sale());
    expect(r).toMatchObject({ no: 'INV-000001', total: 20_000, paid: 20_000, credit: 0, change: 0, status: 'completed', userId: 'u-cashier' });
    expect(r.items[0]).toMatchObject({ cost: 8_000, returnedQty: 0, name: 'Product p1' });
    expect(await stockOf('p1')).toBe(98);
    expect(await cashBalance()).toBe(120_000);
    expect((await s.list('stockMoves', { k2: 'p1' }))[0]).toMatchObject({ qty: -2, type: 'sale', cost: 8_000, refId: r.id });
    expect((await ops.completeSale(s, cashier(), sale())).no).toBe('INV-000002');
  });

  it('gives change from cash and books only the net cash', async () => {
    const r = await ops.completeSale(s, cashier(), sale({ payments: [{ accountId: 'acc-cash', amount: 50_000 }] }));
    expect(r).toMatchObject({ change: 30_000, paid: 20_000 });
    expect(await cashBalance()).toBe(120_000);
  });

  it('splits across wallets and refuses over-payment by wallet or change from a wallet', async () => {
    await ops.completeSale(s, cashier(), sale({ payments: [{ accountId: 'acc-cash', amount: 5_000 }, { accountId: 'acc-easypaisa', amount: 15_000 }] }));
    expect(await ops.accountBalance(s, 'acc-easypaisa')).toBe(15_000);
    await expect(ops.completeSale(s, cashier(), sale({ payments: [{ accountId: 'acc-easypaisa', amount: 30_000 }] }))).rejects.toThrow(/more than the bill/);
  });

  it('puts the unpaid part on the customer khata, and needs a customer and the credit permission', async () => {
    const r = await ops.completeSale(s, cashier(), sale({ customerId: 'c1', payments: [{ accountId: 'acc-cash', amount: 5_000 }] }));
    expect(r).toMatchObject({ credit: 15_000, paid: 5_000, paymentMethod: 'credit' });
    expect(await s.sum('partyEntries', 'amount', { k2: 'customer:c1' })).toBe(15_000);
    await expect(ops.completeSale(s, cashier(), sale({ payments: [] }))).rejects.toThrow(/Select a customer/);
    const noCredit = ctxFor(['pos.use']);
    await expect(ops.completeSale(s, noCredit, sale({ customerId: 'c1', payments: [] }))).rejects.toMatchObject({ status: 403 });
    await expect(ops.completeSale(s, cashier(), sale({ customerId: 'nobody', payments: [] }))).rejects.toThrow(/available customer/);
  });

  it('is atomic in intent: a rejected sale leaves no trace', async () => {
    await expect(ops.completeSale(s, cashier(), sale({ items: [{ productId: 'p1', qty: 1, price: 10_000, discount: 0 }, { productId: 'ghost', qty: 1, price: 1, discount: 0 }] }))).rejects.toThrow(/unavailable/);
    expect(await stockOf('p1')).toBe(100);
    expect(await s.list('sales')).toHaveLength(0);
  });

  it('refuses people without pos.use, inactive products, and malformed lines', async () => {
    await expect(ops.completeSale(s, ctxFor(['products.view']), sale())).rejects.toMatchObject({ status: 403 });
    await s.put('products', product('p3', { active: false }));
    await expect(ops.completeSale(s, cashier(), sale({ items: [{ productId: 'p3', qty: 1, price: 10_000, discount: 0 }] }))).rejects.toThrow(/unavailable/);
    for (const bad of [{ qty: 0 }, { qty: -1 }, { price: -5 }, { price: 10.5 }, { discount: -1 }, { qty: Number.NaN }]) {
      await expect(ops.completeSale(s, cashier(), sale({ items: [{ productId: 'p1', qty: 1, price: 10_000, discount: 0, ...bad }] }))).rejects.toThrow();
    }
    await expect(ops.completeSale(s, cashier(), sale({ items: [] }))).rejects.toThrow(/empty/);
    await expect(ops.completeSale(s, cashier(), sale({ items: [{ productId: 'p1', qty: 1, price: 10_000, discount: 0 }, { productId: 'p1', qty: 1, price: 10_000, discount: 0 }] }))).rejects.toThrow(/twice/);
    await expect(ops.completeSale(s, cashier(), sale({ payments: [{ accountId: 'acc-cash', amount: -5 }] }))).rejects.toThrow();
    await expect(ops.completeSale(s, cashier(), sale({ discount: -100 }))).rejects.toThrow();
  });

  it('ignores a price the cashier typed unless they may override prices', async () => {
    const cheap = sale({ items: [{ productId: 'p1', qty: 1, price: 1, discount: 0 }], payments: [{ accountId: 'acc-cash', amount: 1 }] });
    await expect(ops.completeSale(s, cashier(), cheap)).rejects.toMatchObject({ code: 'PRICE_OVERRIDE_DENIED' });
    const r = await ops.completeSale(s, manager(), { ...cheap, payments: [{ accountId: 'acc-cash', amount: 1 }] }).catch(() => null);
    expect(r === null || r.items[0]!.price === 1).toBe(true); // managers have sales.price_override
    const ok = await ops.completeSale(s, owner(), cheap);
    expect(ok.items[0]!.price).toBe(1);
  });

  it('applies the automatic big-bill discount on the server whatever the browser says', async () => {
    await s.put('products', product('big', { salePrice: 100_000, cost: 50_000 }));
    const r = await ops.completeSale(s, cashier(), { items: [{ productId: 'big', qty: 6, price: 100_000, discount: 0 }], discount: 0, payments: [{ accountId: 'acc-cash', amount: 600_000 }] });
    expect(r.total).toBeLessThan(600_000); // Rs 6,000 is above the Rs 5,000 threshold, so the default 10% applies
    expect(r.items[0]!.discount).toBeGreaterThan(0);
  });

  it('limits hand-typed bill discounts for people who may not exceed the limit', async () => {
    await expect(ops.completeSale(s, cashier(), sale({ discount: 5_000, payments: [{ accountId: 'acc-cash', amount: 15_000 }] }))).rejects.toMatchObject({ code: 'DISCOUNT_LIMIT' });
    const small = await ops.completeSale(s, cashier(), sale({ discount: 500, payments: [{ accountId: 'acc-cash', amount: 19_500 }] }));
    expect(small.total).toBe(19_500);
    const big = await ops.completeSale(s, manager(), sale({ discount: 5_000, payments: [{ accountId: 'acc-cash', amount: 15_000 }] }));
    expect(big.total).toBe(15_000);
  });

  it('marks a linked home-delivery order as delivered', async () => {
    await s.put('gharOrders', { id: 'g1', no: 'G-1', date: '2026-10-04T09:00:00.000Z', customerId: 'c1', customerName: 'Ali', address: 'x', items: [], subtotal: 0, deliveryFee: 0, total: 0, status: 'out_for_delivery', userId: 'u' });
    const r = await ops.completeSale(s, cashier(), sale({ gharOrderId: 'g1', customerId: 'c1', payments: [{ accountId: 'acc-cash', amount: 20_000 }] }));
    expect(await s.get('gharOrders', 'g1')).toMatchObject({ status: 'delivered', saleId: r.id });
  });
});

describe('returns and voids', () => {
  let made: Sale;
  beforeEach(async () => {
    made = await ops.completeSale(s, cashier(), sale({ items: [{ productId: 'p1', qty: 4, price: 10_000, discount: 0 }], customerId: 'c1', payments: [{ accountId: 'acc-cash', amount: 10_000 }] }));
  });

  it('returns part of a sale to the cash drawer and the shelf, never more than was sold', async () => {
    const r = await ops.returnSaleItems(s, cashier(), { saleId: made.id, lines: [{ productId: 'p1', qty: 1 }], refundTo: 'account' });
    expect(r.amount).toBe(10_000);
    expect(await stockOf('p1')).toBe(97);
    expect(await cashBalance()).toBe(100_000 + 10_000 - 10_000);
    expect((await s.get<Sale>('sales', made.id))).toMatchObject({ returnedTotal: 10_000, items: [{ returnedQty: 1 }] });
    await expect(ops.returnSaleItems(s, cashier(), { saleId: made.id, lines: [{ productId: 'p1', qty: 4 }], refundTo: 'account' })).rejects.toThrow(/more Product p1/);
    await expect(ops.returnSaleItems(s, cashier(), { saleId: made.id, lines: [{ productId: 'nope', qty: 1 }], refundTo: 'account' })).rejects.toThrow(/not in this sale/);
    await expect(ops.returnSaleItems(s, cashier(), { saleId: made.id, lines: [], refundTo: 'account' })).rejects.toThrow(/Nothing to return/);
  });

  it('can credit the customer khata instead, and needs sales.return', async () => {
    await ops.returnSaleItems(s, cashier(), { saleId: made.id, lines: [{ productId: 'p1', qty: 2 }], refundTo: 'khata' });
    expect(await s.sum('partyEntries', 'amount', { k2: 'customer:c1' })).toBe(30_000 - 20_000);
    await expect(ops.returnSaleItems(s, ctxFor(['pos.use']), { saleId: made.id, lines: [{ productId: 'p1', qty: 1 }], refundTo: 'account' })).rejects.toMatchObject({ status: 403 });
  });

  it('voids a whole sale: stock back, money and khata reversed; only with sales.void', async () => {
    await expect(ops.voidSale(s, cashier(), made.id, 'mistake')).rejects.toMatchObject({ status: 403 });
    await ops.voidSale(s, manager(), made.id, 'mistake');
    expect(await stockOf('p1')).toBe(100);
    expect(await cashBalance()).toBe(100_000);
    expect(await s.sum('partyEntries', 'amount', { k2: 'customer:c1' })).toBe(0);
    expect(await s.get('sales', made.id)).toMatchObject({ status: 'void', note: 'mistake' });
    await expect(ops.voidSale(s, manager(), made.id, 'again')).rejects.toThrow(/not found/);
  });

  it('will not void a sale that already had returns', async () => {
    await ops.returnSaleItems(s, cashier(), { saleId: made.id, lines: [{ productId: 'p1', qty: 1 }], refundTo: 'account' });
    await expect(ops.voidSale(s, manager(), made.id, 'x')).rejects.toThrow(/already returned/);
  });
});

describe('purchases and stock', () => {
  it('receives stock at a weighted average cost, owes the supplier the unpaid part, and pays from accounts', async () => {
    const p = await ops.recordPurchase(s, manager(), { supplierId: 's1', items: [{ productId: 'p1', qty: 100, cost: 10_000 }], payments: [{ accountId: 'acc-cash', amount: 400_000 }] });
    expect(p).toMatchObject({ no: 'PUR-000001', total: 1_000_000, paid: 400_000 });
    const after = (await s.get<Product>('products', 'p1'))!;
    expect(after.stock).toBe(200);
    expect(after.cost).toBe(9_000); // (100 × 80 + 100 × 100) / 200
    expect(await s.sum('partyEntries', 'amount', { k2: 'supplier:s1' })).toBe(600_000);
    expect(await cashBalance()).toBe(100_000 - 400_000);
  });

  it('refuses overpayment, empty or invalid purchases, unknown suppliers, and missing permissions', async () => {
    const base = { supplierId: 's1', items: [{ productId: 'p1', qty: 1, cost: 100 }], payments: [] };
    await expect(ops.recordPurchase(s, manager(), { ...base, payments: [{ accountId: 'acc-cash', amount: 500 }] })).rejects.toThrow(/exceeds/);
    await expect(ops.recordPurchase(s, manager(), { ...base, items: [] })).rejects.toThrow(/at least one/);
    await expect(ops.recordPurchase(s, manager(), { ...base, items: [{ productId: 'p1', qty: 1, cost: -1 }] })).rejects.toThrow();
    await expect(ops.recordPurchase(s, manager(), { ...base, supplierId: 'nobody' })).rejects.toThrow(/Supplier not found/);
    await expect(ops.recordPurchase(s, cashier(), base)).rejects.toMatchObject({ status: 403 });
  });

  it('adjusts stock with a reason and updates average cost only when adding stock with a cost', async () => {
    await ops.adjustStock(s, manager(), { productId: 'p1', qty: -3, type: 'damage', note: 'broken' });
    expect(await stockOf('p1')).toBe(97);
    expect((await s.list('stockMoves', { k2: 'p1' }))[0]).toMatchObject({ qty: -3, type: 'damage', cost: 8_000, note: 'broken' });
    await expect(ops.adjustStock(s, manager(), { productId: 'p1', qty: 0, type: 'adjust' })).rejects.toThrow(/zero/);
    await expect(ops.adjustStock(s, cashier(), { productId: 'p1', qty: 1, type: 'adjust' })).rejects.toMatchObject({ status: 403 });
  });
});

describe('khata, expenses, transfers, Easypaisa and closing', () => {
  it('records customer and supplier payments on both the khata and the account', async () => {
    await ops.addPartyAdjustment(s, owner(), { partyType: 'customer', partyId: 'c1', amount: 50_000, note: 'opening', type: 'opening' });
    await ops.receiveCustomerPayment(s, cashier(), 'c1', 20_000, 'acc-cash');
    expect(await s.sum('partyEntries', 'amount', { k2: 'customer:c1' })).toBe(30_000);
    expect(await cashBalance()).toBe(120_000);
    await ops.paySupplier(s, manager(), 's1', 10_000, 'acc-cash');
    expect(await s.sum('partyEntries', 'amount', { k2: 'supplier:s1' })).toBe(-10_000);
    await expect(ops.paySupplier(s, cashier(), 's1', 1, 'acc-cash')).rejects.toMatchObject({ status: 403 });
    await expect(ops.receiveCustomerPayment(s, cashier(), 'c1', 0, 'acc-cash')).rejects.toThrow(/amount/);
    await expect(ops.receiveCustomerPayment(s, cashier(), 'ghost', 5, 'acc-cash')).rejects.toThrow(/Customer not found/);
  });

  it('books expenses against an account, owner drawings only for the owner, and deleting removes the money entry', async () => {
    const e = await ops.addExpense(s, manager(), { kind: 'expense', category: 'Electricity', amount: 5_000, accountId: 'acc-cash' });
    expect(await cashBalance()).toBe(95_000);
    await expect(ops.addExpense(s, manager(), { kind: 'drawing', category: 'Owner', amount: 1, accountId: 'acc-cash' })).rejects.toMatchObject({ status: 403 });
    await ops.addExpense(s, owner(), { kind: 'drawing', category: 'Owner', amount: 10_000, accountId: 'acc-cash' });
    expect(await cashBalance()).toBe(85_000);
    await ops.deleteExpense(s, manager(), e.id);
    expect(await cashBalance()).toBe(90_000);
    await expect(ops.deleteExpense(s, cashier(), e.id)).rejects.toMatchObject({ status: 403 });
    await expect(ops.addExpense(s, manager(), { kind: 'expense', category: '', amount: 5, accountId: 'acc-cash' })).rejects.toThrow(/category/);
    await expect(ops.addExpense(s, manager(), { kind: 'expense', category: 'x', amount: 5, accountId: 'nope' })).rejects.toThrow(/unavailable/);
  });

  it('transfers between accounts and adjusts one with permission', async () => {
    await ops.transferMoney(s, manager(), 'acc-cash', 'acc-bank', 30_000);
    expect(await cashBalance()).toBe(70_000);
    expect(await ops.accountBalance(s, 'acc-bank')).toBe(30_000);
    await expect(ops.transferMoney(s, manager(), 'acc-cash', 'acc-cash', 1)).rejects.toThrow(/two different/);
    await expect(ops.adjustAccount(s, manager(), 'acc-cash', 5, 'x')).rejects.toMatchObject({ status: 403 });
    await ops.adjustAccount(s, owner(), 'acc-cash', -500, 'recount');
    expect(await cashBalance()).toBe(69_500);
  });

  it('moves both the wallet float and the cash for an Easypaisa cash-in, with fee and commission, and reverses it', async () => {
    await ops.adjustAccount(s, owner(), 'acc-easypaisa', 1_000_000, 'float');
    const t = await ops.addServiceTxn(s, cashier(), { provider: 'Easypaisa', type: 'cash_in', amount: 500_000, fee: 2_000, commission: 5_000 });
    expect(await ops.accountBalance(s, 'acc-easypaisa')).toBe(1_000_000 - 500_000 + 5_000);
    expect(await cashBalance()).toBe(100_000 + 500_000 + 2_000);
    await ops.deleteServiceTxn(s, manager(), t.id);
    expect(await ops.accountBalance(s, 'acc-easypaisa')).toBe(1_000_000);
    expect(await cashBalance()).toBe(100_000);
    await expect(ops.deleteServiceTxn(s, cashier(), t.id)).rejects.toMatchObject({ status: 403 });
    await expect(ops.addServiceTxn(s, cashier(), { provider: 'Nobody', type: 'cash_in', amount: 5, fee: 0, commission: 0 })).rejects.toThrow(/No account/);
  });

  it('closes the day: expected comes from the books and the difference is booked so tomorrow starts true', async () => {
    await ops.completeSale(s, cashier(), sale());
    await ops.saveClosing(s, cashier(), { accountId: 'acc-cash', counted: 118_000, note: 'short' });
    const [closing] = await s.list('closings');
    expect(closing).toMatchObject({ expected: 120_000, counted: 118_000, difference: -2_000, userId: 'u-cashier' });
    expect(await cashBalance()).toBe(118_000);
    const adj = (await s.list<AccountTxn>('accountTxns', { k4: (closing as { id: string }).id }))[0];
    expect(adj).toMatchObject({ amount: -2_000, type: 'adjustment' });
    await expect(ops.saveClosing(s, ctxFor(['pos.use']), { accountId: 'acc-cash', counted: 1 })).rejects.toMatchObject({ status: 403 });
    await expect(ops.saveClosing(s, cashier(), { accountId: 'acc-cash', counted: -1 })).rejects.toThrow();
  });
});

describe('numbering', () => {
  it('never repeats a document number', async () => {
    const numbers = new Set<string>();
    for (let i = 0; i < 5; i++) numbers.add((await ops.completeSale(s, cashier(), sale())).no);
    expect(numbers.size).toBe(5);
  });
});
