import type { Permission } from '@retailos/domain';
import type { FastifyPluginAsyncZod } from 'fastify-type-provider-zod';
import { z } from 'zod';
import { forbidden } from '../../lib/errors.js';
import { ShopReports } from './reports.js';

/**
 * Report endpoints: `GET /shop/reports/*`. Each one checks the caller's permission on the server, then
 * runs SQL aggregates (see reports.ts) and returns only the finished figures. Cost, profit and ledger
 * numbers are never produced for a caller who may not see them.
 */

/** The browser's own range bounds (start of first day, end of last day, as ISO instants). */
const Iso = z.string().min(10).max(40).regex(/^\d{4}-\d{2}-\d{2}/);
const Range = z.object({ start: Iso, end: Iso });
const Id = z.string().min(1).max(64).regex(/^[A-Za-z0-9._:-]+$/);

export const reportRoutes: FastifyPluginAsyncZod = async (app) => {
  const ctxOf = (request: { ctx: { tenantId: string; userId: string; permissions: ReadonlySet<string> } }) => {
    const can = (p: Permission) => request.ctx.permissions.has(p);
    const need = (...any: Permission[]) => {
      if (!any.some(can)) throw forbidden();
    };
    return { can, need, userId: request.ctx.userId, reports: new ShopReports(app.db, request.ctx.tenantId) };
  };

  app.get('/profit', { schema: { querystring: Range } }, async (request) => {
    const { need, reports } = ctxOf(request);
    need('reports.profit', 'dashboard.owner');
    return reports.profit(request.query.start, request.query.end);
  });

  app.get('/products', { schema: { querystring: Range } }, async (request) => {
    const { need, reports } = ctxOf(request);
    need('reports.profit');
    return reports.productSales(request.query.start, request.query.end);
  });

  app.get('/top-products', { schema: { querystring: Range.extend({ limit: z.coerce.number().int().min(1).max(50).default(5) }) } }, async (request) => {
    const { need, reports } = ctxOf(request);
    need('sales.view_all', 'dashboard.owner', 'reports.sales');
    return reports.topProducts(request.query.start, request.query.end, request.query.limit);
  });

  /** Bars for several day ranges at once. `ranges` is a JSON list of [start, end] pairs. */
  const Ranges = z
    .string()
    .max(6000)
    .transform((text, ctx) => {
      try {
        return z.array(z.tuple([Iso, Iso])).min(1).max(62).parse(JSON.parse(text));
      } catch {
        ctx.addIssue({ code: 'custom', message: 'ranges must be a list of [start, end] pairs' });
        return z.NEVER;
      }
    });
  app.get('/daily-sales', { schema: { querystring: z.object({ ranges: Ranges }) } }, async (request) => {
    const { need, reports } = ctxOf(request);
    need('sales.view_all', 'dashboard.owner', 'reports.sales');
    return reports.dailySales(request.query.ranges);
  });

  app.get('/sales-summary', { schema: { querystring: Range } }, async (request) => {
    const { can, need, userId, reports } = ctxOf(request);
    need('sales.view_all', 'sales.view_own');
    return reports.salesSummary(request.query.start, request.query.end, can('sales.view_all') ? undefined : userId);
  });

  app.get('/sales-velocity', { schema: { querystring: z.object({ since: Iso }) } }, async (request) => {
    const { need, reports } = ctxOf(request);
    need('pos.use');
    return reports.salesVelocity(request.query.since);
  });

  app.get('/expenses', { schema: { querystring: Range } }, async (request) => {
    const { need, reports } = ctxOf(request);
    need('expenses.view');
    return reports.expenses(request.query.start, request.query.end);
  });

  app.get('/purchases', { schema: { querystring: Range } }, async (request) => {
    const { need, reports } = ctxOf(request);
    need('purchasing.view', 'suppliers.view_balance');
    return reports.purchases(request.query.start, request.query.end);
  });

  app.get('/cash-breakdown', { schema: { querystring: Range.extend({ accountId: Id }) } }, async (request) => {
    const { need, reports } = ctxOf(request);
    need('accounts.view_balances');
    return reports.cashBreakdown(request.query.accountId, request.query.start, request.query.end);
  });

  app.get('/services', { schema: { querystring: Range.extend({ provider: Id }) } }, async (request) => {
    const { can, need, userId, reports } = ctxOf(request);
    need('retailer.transact', 'retailer.view_all');
    return reports.services(request.query.provider, request.query.start, request.query.end, can('retailer.view_all') ? undefined : userId);
  });

  /** Credit totals. Each half is only present when the caller may see that kind of balance. */
  app.get('/khata', async (request) => {
    const { can, need, reports } = ctxOf(request);
    need('customers.view_balance', 'suppliers.view_balance');
    const k = await reports.khata();
    return {
      ...(can('customers.view_balance') ? { customerDue: k.customerDue, customersWithDue: k.customersWithDue, overLimit: k.overLimit } : {}),
      ...(can('suppliers.view_balance') ? { supplierDue: k.supplierDue, supplierAccounts: k.supplierAccounts } : {}),
    };
  });

  app.get(
    '/reorder',
    {
      schema: {
        querystring: z.object({
          now: z.coerce.number().int().min(0),
          tz: z.coerce.number().int().min(-840).max(840),
          lead: z.coerce.number().int().min(0).max(120).default(3),
          cover: z.coerce.number().int().min(1).max(60).default(7),
          rows: z.enum(['0', '1']).default('1'),
        }),
      },
    },
    async (request) => {
      const { can, need, reports } = ctxOf(request);
      need('inventory.view', 'reports.inventory');
      const { dayNumberOf } = await import('@retailos/domain');
      const q = request.query;
      const result = await reports.reorder({
        today: dayNumberOf(q.now, q.tz),
        nowMs: q.now,
        defaultLeadDays: q.lead,
        coverDays: q.cover,
        includeRows: q.rows === '1',
        showCost: can('products.view_cost'),
      });
      return { ...result, summary: { ...result.summary, stockValue: can('inventory.view_value') ? result.summary.stockValue : null } };
    },
  );
};
